package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Sensor;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.SensorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = SensorController.class)
@Import(SensorControllerTest.MockConfig.class)
class SensorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private SensorService sensorService;

    @Autowired
    private AreaRiscoService areaRiscoService;

    @BeforeEach
    void setUp() {
        Sensor sensor = new Sensor();
        sensor.setIdSensor(1L);
        sensor.setTipoSensor("Temperatura");

        AreaRisco area = new AreaRisco();
        area.setIdArea(1L);
        area.setNomeArea("Zona Norte");

        when(sensorService.listarTodos()).thenReturn(List.of(sensor));
        when(sensorService.buscarPorId(1L)).thenReturn(sensor);
        when(areaRiscoService.listarTodos()).thenReturn(List.of(area));
    }

    @Test
    @WithMockUser(roles = {"USER"})
    void deveListarSensores_comUsuarioAutenticado() throws Exception {
        mockMvc.perform(get("/sensores"))
                .andExpect(status().isOk())
                .andExpect(view().name("sensor/lista"))
                .andExpect(model().attributeExists("sensores"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioNovoSensor_comAdmin() throws Exception {
        mockMvc.perform(get("/sensores/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("sensor/form"))
                .andExpect(model().attributeExists("sensor"))
                .andExpect(model().attributeExists("areas"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioEdicaoSensor_comAdmin() throws Exception {
        mockMvc.perform(get("/sensores/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("sensor/form"))
                .andExpect(model().attributeExists("sensor"))
                .andExpect(model().attributeExists("areas"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean
        public SensorService sensorService() {
            return mock(SensorService.class);
        }

        @Bean
        public AreaRiscoService areaRiscoService() {
            return mock(AreaRiscoService.class);
        }
    }
}

package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.SensorEvent;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.model.Sensor;
import br.com.fiap.gs.repository.SensorRepository;
import br.com.fiap.gs.service.impl.SensorImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SensorImplTest {

    @Mock
    private SensorRepository sensorRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @InjectMocks
    private SensorImpl sensorService;

    private Sensor sensor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        AreaRisco area = new AreaRisco();
        area.setIdArea(1L);
        area.setNomeArea("Zona Norte");

        sensor = new Sensor();
        sensor.setIdSensor(1L);
        sensor.setTipoSensor("Temperatura");
        sensor.setDescricao("Sensor térmico");
        sensor.setUnidadeMedida("°C");
        sensor.setStatus("ATIVO");
        sensor.setIntervaloLeitura(30);
        sensor.setDataInstalacao(LocalDateTime.now());
        sensor.setArea(area);
    }

    @Test
    void deveSalvarSensorComSucesso() {
        when(sensorRepository.save(any(Sensor.class))).thenReturn(sensor);

        Sensor salvo = sensorService.salvar(sensor);

        assertNotNull(salvo);
        assertEquals("Temperatura", salvo.getTipoSensor());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(SensorEvent.class));
    }

    @Test
    void deveBuscarPorIdComSucesso() {
        when(sensorRepository.findById(1L)).thenReturn(Optional.of(sensor));

        Sensor encontrado = sensorService.buscarPorId(1L);

        assertNotNull(encontrado);
        assertEquals("Temperatura", encontrado.getTipoSensor());
    }

    @Test
    void deveLancarExcecao_QuandoSensorNaoExiste() {
        when(sensorRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> sensorService.buscarPorId(1L));
    }

    @Test
    void deveAtualizarSensorComSucesso() {
        when(sensorRepository.findById(1L)).thenReturn(Optional.of(sensor));
        when(sensorRepository.save(any(Sensor.class))).thenReturn(sensor);

        Sensor atualizado = new Sensor();
        atualizado.setTipoSensor("Umidade");
        atualizado.setDescricao("Novo sensor");
        atualizado.setUnidadeMedida("%");
        atualizado.setStatus("ATIVO");
        atualizado.setIntervaloLeitura(10);
        atualizado.setDataInstalacao(LocalDateTime.now());
        atualizado.setArea(new AreaRisco());

        Sensor resultado = sensorService.atualizar(1L, atualizado);

        assertEquals("Umidade", resultado.getTipoSensor());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(SensorEvent.class));
    }

    @Test
    void deveDeletarSensorComSucesso() {
        when(sensorRepository.findById(1L)).thenReturn(Optional.of(sensor));

        sensorService.deletar(1L);

        verify(sensorRepository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(SensorEvent.class));
    }
}

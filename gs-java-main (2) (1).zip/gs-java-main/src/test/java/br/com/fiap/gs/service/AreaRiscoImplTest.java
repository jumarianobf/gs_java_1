
package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.AreaRiscoEvent;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.repository.AreaRiscoRepository;
import br.com.fiap.gs.service.impl.AreaRiscoImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AreaRiscoImplTest {

    private AreaRiscoRepository repository;
    private RabbitTemplate rabbitTemplate;
    private AreaRiscoImpl service;

    @BeforeEach
    void setUp() {
        repository = mock(AreaRiscoRepository.class);
        rabbitTemplate = mock(RabbitTemplate.class);
        service = new AreaRiscoImpl(repository, rabbitTemplate);
    }

    @Test
    void deveListarTodos() {
        when(repository.findAll()).thenReturn(List.of(new AreaRisco()));
        assertEquals(1, service.listarTodos().size());
    }

    @Test
    void deveBuscarPorId() {
        AreaRisco a = new AreaRisco();
        a.setIdArea(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(a));
        assertEquals(1L, service.buscarPorId(1L).getIdArea());
    }

    @Test
    void deveSalvarComEvento() {
        AreaRisco a = new AreaRisco();
        a.setIdArea(1L);
        when(repository.save(a)).thenReturn(a);
        AreaRisco salvo = service.salvar(a);
        assertNotNull(salvo);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AreaRiscoEvent.class));
    }

    @Test
    void deveAtualizarComEvento() {
        AreaRisco existente = new AreaRisco();
        existente.setIdArea(1L);
        AreaRisco novo = new AreaRisco();
        novo.setNomeArea("Zona A");
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        when(repository.save(any())).thenReturn(existente);
        AreaRisco atualizado = service.atualizar(1L, novo);
        assertEquals("Zona A", atualizado.getNomeArea());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AreaRiscoEvent.class));
    }

    @Test
    void deveDeletarComEvento() {
        AreaRisco existente = new AreaRisco();
        existente.setIdArea(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        service.deletar(1L);
        verify(repository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AreaRiscoEvent.class));
    }
}

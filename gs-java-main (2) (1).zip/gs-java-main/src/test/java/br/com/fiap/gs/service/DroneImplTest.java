package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.DroneEvent;
import br.com.fiap.gs.model.Drone;
import br.com.fiap.gs.repository.DroneRepository;
import br.com.fiap.gs.service.impl.DroneImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DroneImplTest {

    private DroneRepository repository;
    private RabbitTemplate rabbitTemplate;
    private DroneImpl service;

    @BeforeEach
    void setUp() {
        repository = mock(DroneRepository.class);
        rabbitTemplate = mock(RabbitTemplate.class);
        service = new DroneImpl(repository, rabbitTemplate);
    }

    @Test
    void deveListarTodos() {
        Drone d = Drone.builder().idDrone(1L).build();
        when(repository.findAll()).thenReturn(List.of(d));
        List<Drone> result = service.listarTodos();
        assertEquals(1, result.size());
    }

    @Test
    void deveBuscarPorId() {
        Drone d = Drone.builder().idDrone(1L).build();
        when(repository.findById(1L)).thenReturn(Optional.of(d));
        Drone result = service.buscarPorId(1L);
        assertEquals(1L, result.getIdDrone());
    }

    @Test
    void deveLancarExcecao_QuandoBuscarPorIdInvalido() {
        when(repository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> service.buscarPorId(1L));
    }

    @Test
    void deveSalvarComEvento() {
        Drone d = Drone.builder().idDrone(1L).build();
        when(repository.save(d)).thenReturn(d);
        Drone result = service.salvar(d);
        assertEquals(1L, result.getIdDrone());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(DroneEvent.class));
    }

    @Test
    void deveAtualizarComEvento() {
        Drone existente = Drone.builder().idDrone(1L).build();
        Drone atualizado = Drone.builder().nome("X-Wing").build();

        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        when(repository.save(any())).thenReturn(existente);

        Drone result = service.atualizar(1L, atualizado);
        assertEquals("X-Wing", result.getNome());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(DroneEvent.class));
    }

    @Test
    void deveDeletarComEvento() {
        Drone existente = Drone.builder().idDrone(1L).build();
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        service.deletar(1L);
        verify(repository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(DroneEvent.class));
    }

    @Test
    void deveContarAtivos() {
        when(repository.countAtivos()).thenReturn(3L);
        long count = service.contarAtivos();
        assertEquals(3L, count);
    }
}
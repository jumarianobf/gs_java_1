package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.LogDroneEvent;
import br.com.fiap.gs.model.Drone;
import br.com.fiap.gs.model.LogDrone;
import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.repository.LogDroneRepository;
import br.com.fiap.gs.service.impl.LogDroneImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LogDroneImplTest {

    @Mock private LogDroneRepository logDroneRepository;
    @Mock private RabbitTemplate rabbitTemplate;
    @InjectMocks private LogDroneImpl logDroneService;

    private LogDrone log;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        Drone drone = new Drone();
        drone.setIdDrone(1L);

        Usuario usuario = new Usuario();
        usuario.setIdUsuario(1L);

        log = new LogDrone();
        log.setIdLog(1L);
        log.setDataHora(LocalDateTime.now());
        log.setAcaoRealizada("Decolagem");
        log.setDescricao("Drone decolou corretamente");
        log.setLatitude(-23.5);
        log.setLongitude(-46.6);
        log.setStatus("ATIVO");
        log.setDrone(drone);
        log.setUsuario(usuario);
    }

    @Test
    void deveSalvarLogDroneComSucesso() {
        when(logDroneRepository.save(any())).thenReturn(log);

        LogDrone salvo = logDroneService.salvar(log);

        assertNotNull(salvo);
        assertEquals("Decolagem", salvo.getAcaoRealizada());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(LogDroneEvent.class));
    }

    @Test
    void deveBuscarLogPorIdComSucesso() {
        when(logDroneRepository.findById(1L)).thenReturn(Optional.of(log));

        LogDrone encontrado = logDroneService.buscarPorId(1L);

        assertNotNull(encontrado);
        assertEquals("ATIVO", encontrado.getStatus());
    }

    @Test
    void deveLancarExcecaoSeNaoEncontrarLog() {
        when(logDroneRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> logDroneService.buscarPorId(1L));
    }

    @Test
    void deveAtualizarLogComSucesso() {
        when(logDroneRepository.findById(1L)).thenReturn(Optional.of(log));
        when(logDroneRepository.save(any())).thenReturn(log);

        LogDrone atualizado = new LogDrone();
        atualizado.setAcaoRealizada("Pouso");
        atualizado.setStatus("INATIVO");

        LogDrone resultado = logDroneService.atualizar(1L, atualizado);

        assertEquals("Pouso", resultado.getAcaoRealizada());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(LogDroneEvent.class));
    }

    @Test
    void deveDeletarLogComSucesso() {
        when(logDroneRepository.findById(1L)).thenReturn(Optional.of(log));

        logDroneService.deletar(1L);

        verify(logDroneRepository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(LogDroneEvent.class));
    }
}


package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.ConfigAlertaEvent;
import br.com.fiap.gs.model.ConfigAlerta;
import br.com.fiap.gs.repository.ConfigAlertaRepository;
import br.com.fiap.gs.service.impl.ConfigAlertaImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ConfigAlertaImplTest {

    private ConfigAlertaRepository repository;
    private RabbitTemplate rabbitTemplate;
    private ConfigAlertaImpl service;

    @BeforeEach
    void setUp() {
        repository = mock(ConfigAlertaRepository.class);
        rabbitTemplate = mock(RabbitTemplate.class);
        service = new ConfigAlertaImpl(repository, rabbitTemplate);
    }

    @Test
    void deveListarTodos() {
        ConfigAlerta config = new ConfigAlerta();
        config.setIdConfig(1L);
        when(repository.findAll()).thenReturn(List.of(config));
        List<ConfigAlerta> lista = service.listarTodos();
        assertEquals(1, lista.size());
    }

    @Test
    void deveBuscarPorId() {
        ConfigAlerta config = new ConfigAlerta();
        config.setIdConfig(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(config));
        ConfigAlerta resultado = service.buscarPorId(1L);
        assertEquals(1L, resultado.getIdConfig());
    }

    @Test
    void deveSalvarComEvento() {
        ConfigAlerta config = new ConfigAlerta();
        config.setIdConfig(1L);
        when(repository.save(config)).thenReturn(config);
        ConfigAlerta salvo = service.salvar(config);
        assertNotNull(salvo);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(ConfigAlertaEvent.class));
    }

    @Test
    void deveAtualizarComEvento() {
        ConfigAlerta existente = new ConfigAlerta();
        existente.setIdConfig(1L);

        ConfigAlerta novo = new ConfigAlerta();
        novo.setTipoAlerta("Temperatura");

        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        when(repository.save(any())).thenReturn(existente);

        ConfigAlerta atualizado = service.atualizar(1L, novo);
        assertEquals("Temperatura", atualizado.getTipoAlerta());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(ConfigAlertaEvent.class));
    }

    @Test
    void deveDeletarComEvento() {
        ConfigAlerta existente = new ConfigAlerta();
        existente.setIdConfig(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        service.deletar(1L);
        verify(repository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(ConfigAlertaEvent.class));
    }
}

package br.com.fiap.gs.service;

import br.com.fiap.gs.model.*;
import br.com.fiap.gs.repository.ManutencaoRepository;
import br.com.fiap.gs.service.impl.ManutencaoImpl;
import br.com.fiap.gs.messaging.ManutencaoEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ManutencaoImplTest {

    @Mock
    private ManutencaoRepository manutencaoRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @InjectMocks
    private ManutencaoImpl manutencaoService;

    private Manutencao manutencao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        Drone drone = new Drone();
        drone.setIdDrone(1L);

        Sensor sensor = new Sensor();
        sensor.setIdSensor(1L);

        Sinalizacao sinalizacao = new Sinalizacao();
        sinalizacao.setIdSinalizacao(1L);

        Usuario usuario = new Usuario();
        usuario.setIdUsuario(1L);

        manutencao = new Manutencao();
        manutencao.setIdManutencao(1L);
        manutencao.setTipo("Preventiva");
        manutencao.setDataAgendada(LocalDateTime.now());
        manutencao.setStatus("PENDENTE");
        manutencao.setObservacoes("Teste");
        manutencao.setDrone(drone);
        manutencao.setSensor(sensor);
        manutencao.setSinalizacao(sinalizacao);
        manutencao.setUsuario(usuario);
    }

    @Test
    void deveSalvarManutencaoComSucesso() {
        when(manutencaoRepository.save(any())).thenReturn(manutencao);

        Manutencao salvo = manutencaoService.salvar(manutencao);

        assertNotNull(salvo);
        assertEquals("Preventiva", salvo.getTipo());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(ManutencaoEvent.class));
    }

    @Test
    void deveBuscarPorIdComSucesso() {
        when(manutencaoRepository.findById(1L)).thenReturn(Optional.of(manutencao));

        Manutencao encontrada = manutencaoService.buscarPorId(1L);

        assertNotNull(encontrada);
        assertEquals("Preventiva", encontrada.getTipo());
    }

    @Test
    void deveLancarExcecao_QuandoIdInexistente() {
        when(manutencaoRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> manutencaoService.buscarPorId(1L));
    }

    @Test
    void deveAtualizarManutencaoComSucesso() {
        when(manutencaoRepository.findById(1L)).thenReturn(Optional.of(manutencao));
        when(manutencaoRepository.save(any())).thenReturn(manutencao);

        Manutencao atualizada = new Manutencao();
        atualizada.setTipo("Corretiva");
        atualizada.setStatus("CONCLUIDA");

        Manutencao resultado = manutencaoService.atualizar(1L, atualizada);

        assertEquals("Corretiva", resultado.getTipo());
        assertEquals("CONCLUIDA", resultado.getStatus());
    }

    @Test
    void deveDeletarManutencaoComSucesso() {
        when(manutencaoRepository.findById(1L)).thenReturn(Optional.of(manutencao));

        manutencaoService.deletar(1L);

        verify(manutencaoRepository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(ManutencaoEvent.class));
    }
}

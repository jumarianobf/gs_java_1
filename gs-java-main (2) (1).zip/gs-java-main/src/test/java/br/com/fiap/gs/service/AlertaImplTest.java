
package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.AlertaEvent;
import br.com.fiap.gs.model.Alerta;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.model.Drone;
import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.repository.AlertaRepository;
import br.com.fiap.gs.service.impl.AlertaImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AlertaImplTest {
    private AlertaRepository repository;
    private RabbitTemplate rabbitTemplate;
    private AlertaImpl service;

    @BeforeEach
    void setUp() {
        repository = mock(AlertaRepository.class);
        rabbitTemplate = mock(RabbitTemplate.class);
        service = new AlertaImpl(repository, rabbitTemplate);
    }

    @Test
    void deveListarTodos() {
        when(repository.findAll()).thenReturn(List.of(new Alerta()));
        assertEquals(1, service.listarTodos().size());
    }

    @Test
    void deveBuscarPorId() {
        Alerta alerta = new Alerta();
        alerta.setIdAlerta(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(alerta));
        assertEquals(1L, service.buscarPorId(1L).getIdAlerta());
    }

    @Test
    void deveSalvarComEvento() {
        Alerta alerta = new Alerta();
        alerta.setIdAlerta(1L);
        alerta.setArea(new AreaRisco());
        alerta.setUsuario(new Usuario());
        alerta.setDrone(new Drone());
        when(repository.save(alerta)).thenReturn(alerta);
        Alerta salvo = service.salvar(alerta);
        assertNotNull(salvo);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AlertaEvent.class));
    }

    @Test
    void deveAtualizarComEvento() {
        Alerta existente = new Alerta();
        existente.setIdAlerta(1L);
        Alerta novo = new Alerta();
        novo.setArea(new AreaRisco());
        novo.setDrone(new Drone());
        novo.setUsuario(new Usuario());
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        when(repository.save(any())).thenReturn(existente);
        Alerta atualizado = service.atualizar(1L, novo);
        assertNotNull(atualizado);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AlertaEvent.class));
    }

    @Test
    void deveDeletarComEvento() {
        Alerta existente = new Alerta();
        existente.setIdAlerta(1L);
        existente.setArea(new AreaRisco());
        existente.setDrone(new Drone());
        existente.setUsuario(new Usuario());
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        service.deletar(1L);
        verify(repository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AlertaEvent.class));
    }
}

package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.HistoricoPrevisaoEvent;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.model.HistoricoPrevisao;
import br.com.fiap.gs.repository.HistoricoPrevisaoRepository;
import br.com.fiap.gs.service.impl.HistoricoPrevisaoImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HistoricoPrevisaoImplTest {

    private HistoricoPrevisaoRepository repository;
    private RabbitTemplate rabbitTemplate;
    private HistoricoPrevisaoImpl service;

    @BeforeEach
    void setUp() {
        repository = mock(HistoricoPrevisaoRepository.class);
        rabbitTemplate = mock(RabbitTemplate.class);
        service = new HistoricoPrevisaoImpl(repository, rabbitTemplate);
    }

    @Test
    void deveListarTodos() {
        HistoricoPrevisao h = HistoricoPrevisao.builder().idPrevisao(1L).build();
        when(repository.findAll()).thenReturn(List.of(h));
        List<HistoricoPrevisao> result = service.listarTodos();
        assertEquals(1, result.size());
    }

    @Test
    void deveBuscarPorId() {
        HistoricoPrevisao h = HistoricoPrevisao.builder().idPrevisao(1L).build();
        when(repository.findById(1L)).thenReturn(Optional.of(h));
        HistoricoPrevisao result = service.buscarPorId(1L);
        assertEquals(1L, result.getIdPrevisao());
    }

    @Test
    void deveLancarExcecao_QuandoBuscarPorIdInvalido() {
        when(repository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> service.buscarPorId(1L));
    }

    @Test
    void deveSalvarComEvento() {
        AreaRisco area = AreaRisco.builder().idArea(1L).nomeArea("Teste").build();
        HistoricoPrevisao h = HistoricoPrevisao.builder().idPrevisao(1L).area(area).build();
        when(repository.save(h)).thenReturn(h);
        HistoricoPrevisao result = service.salvar(h);
        assertEquals(1L, result.getIdPrevisao());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(HistoricoPrevisaoEvent.class));
    }

    @Test
    void deveAtualizarComEvento() {
        AreaRisco area = AreaRisco.builder().idArea(1L).nomeArea("Teste").build();
        HistoricoPrevisao existente = HistoricoPrevisao.builder().idPrevisao(1L).area(area).build();
        HistoricoPrevisao atualizado = HistoricoPrevisao.builder().tipoEvento("Chuva").area(area).build();

        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        when(repository.save(any())).thenReturn(existente);

        HistoricoPrevisao result = service.atualizar(1L, atualizado);
        assertEquals("Chuva", result.getTipoEvento());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(HistoricoPrevisaoEvent.class));
    }

    @Test
    void deveDeletarComEvento() {
        HistoricoPrevisao existente = HistoricoPrevisao.builder().idPrevisao(1L).area(new AreaRisco()).build();
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        service.deletar(1L);
        verify(repository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(HistoricoPrevisaoEvent.class));
    }
}
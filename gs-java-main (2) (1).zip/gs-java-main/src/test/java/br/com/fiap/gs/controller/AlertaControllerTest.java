
package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Alerta;
import br.com.fiap.gs.service.AlertaService;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.DroneService;
import br.com.fiap.gs.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = AlertaController.class)
@Import(AlertaControllerTest.MockConfig.class)
class AlertaControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private AlertaService alertaService;
    @Autowired private AreaRiscoService areaRiscoService;
    @Autowired private DroneService droneService;
    @Autowired private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        when(alertaService.listarTodos()).thenReturn(List.of(new Alerta()));
        when(alertaService.buscarPorId(1L)).thenReturn(new Alerta());
        when(areaRiscoService.listarTodos()).thenReturn(List.of());
        when(droneService.listarTodos()).thenReturn(List.of());
        when(usuarioService.listarTodos()).thenReturn(List.of());
    }

    @Test
    @WithMockUser(roles = {"USER"})
    void deveListarAlertas() throws Exception {
        mockMvc.perform(get("/alerta"))
                .andExpect(status().isOk())
                .andExpect(view().name("alerta/lista"))
                .andExpect(model().attributeExists("alertas"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioNovo() throws Exception {
        mockMvc.perform(get("/alerta/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("alerta/form"))
                .andExpect(model().attributeExists("alerta"))
                .andExpect(model().attributeExists("areas"))
                .andExpect(model().attributeExists("drones"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioEdicao() throws Exception {
        mockMvc.perform(get("/alerta/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("alerta/form"))
                .andExpect(model().attributeExists("alerta"))
                .andExpect(model().attributeExists("areas"))
                .andExpect(model().attributeExists("drones"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean AlertaService alertaService() { return mock(AlertaService.class); }
        @Bean AreaRiscoService areaRiscoService() { return mock(AreaRiscoService.class); }
        @Bean DroneService droneService() { return mock(DroneService.class); }
        @Bean UsuarioService usuarioService() { return mock(UsuarioService.class); }
    }
}

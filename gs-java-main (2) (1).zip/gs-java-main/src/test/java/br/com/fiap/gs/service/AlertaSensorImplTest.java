
package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.AlertaSensorEvent;
import br.com.fiap.gs.model.AlertaSensor;
import br.com.fiap.gs.model.Alerta;
import br.com.fiap.gs.model.Sensor;
import br.com.fiap.gs.repository.AlertaSensorRepository;
import br.com.fiap.gs.service.impl.AlertaSensorImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AlertaSensorImplTest {

    private AlertaSensorRepository repository;
    private RabbitTemplate rabbitTemplate;
    private AlertaSensorImpl service;

    @BeforeEach
    void setUp() {
        repository = mock(AlertaSensorRepository.class);
        rabbitTemplate = mock(RabbitTemplate.class);
        service = new AlertaSensorImpl(repository, rabbitTemplate);
    }

    @Test
    void deveListarTodos() {
        when(repository.findAll()).thenReturn(List.of(new AlertaSensor()));
        assertEquals(1, service.listarTodos().size());
    }

    @Test
    void deveBuscarPorId() {
        AlertaSensor a = new AlertaSensor();
        a.setIdAlertaSensor(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(a));
        assertEquals(1L, service.buscarPorId(1L).getIdAlertaSensor());
    }

    @Test
    void deveSalvarComEvento() {
        AlertaSensor a = new AlertaSensor();
        a.setIdAlertaSensor(1L);
        a.setAlerta(new Alerta());
        a.setSensor(new Sensor());
        when(repository.save(a)).thenReturn(a);
        AlertaSensor salvo = service.salvar(a);
        assertNotNull(salvo);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AlertaSensorEvent.class));
    }

    @Test
    void deveAtualizarComEvento() {
        AlertaSensor existente = new AlertaSensor();
        existente.setIdAlertaSensor(1L);
        AlertaSensor novo = new AlertaSensor();
        novo.setValorDisparo(99.0);
        novo.setAlerta(new Alerta());
        novo.setSensor(new Sensor());
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        when(repository.save(any())).thenReturn(existente);
        AlertaSensor atualizado = service.atualizar(1L, novo);
        assertEquals(99.0, atualizado.getValorDisparo());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AlertaSensorEvent.class));
    }

    @Test
    void deveDeletarComEvento() {
        AlertaSensor existente = new AlertaSensor();
        existente.setIdAlertaSensor(1L);
        existente.setAlerta(new Alerta());
        existente.setSensor(new Sensor());
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        service.deletar(1L);
        verify(repository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(AlertaSensorEvent.class));
    }
}

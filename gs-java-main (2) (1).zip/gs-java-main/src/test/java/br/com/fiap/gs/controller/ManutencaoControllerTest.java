package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Manutencao;
import br.com.fiap.gs.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = ManutencaoController.class)
@Import(ManutencaoControllerTest.MockConfig.class)
class ManutencaoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ManutencaoService manutencaoService;

    @Autowired
    private DroneService droneService;

    @Autowired
    private SensorService sensorService;

    @Autowired
    private SinalizacaoService sinalizacaoService;

    @Autowired
    private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        Manutencao manutencao = new Manutencao();
        manutencao.setIdManutencao(1L);
        manutencao.setTipo("Preventiva");

        when(manutencaoService.listarTodos()).thenReturn(List.of(manutencao));
        when(manutencaoService.buscarPorId(1L)).thenReturn(manutencao);
        when(droneService.listarTodos()).thenReturn(List.of());
        when(sensorService.listarTodos()).thenReturn(List.of());
        when(sinalizacaoService.listarTodos()).thenReturn(List.of());
        when(usuarioService.listarTodos()).thenReturn(List.of());
    }

    @Test
    @WithMockUser(roles = {"USER"})
    void deveListarManutencoes_comUsuario() throws Exception {
        mockMvc.perform(get("/manutencoes"))
                .andExpect(status().isOk())
                .andExpect(view().name("manutencao/lista"))
                .andExpect(model().attributeExists("manutencoes"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioNovaManutencao() throws Exception {
        mockMvc.perform(get("/manutencoes/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("manutencao/form"))
                .andExpect(model().attributeExists("manutencao"))
                .andExpect(model().attributeExists("drones"))
                .andExpect(model().attributeExists("sensores"))
                .andExpect(model().attributeExists("sinalizacoes"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioEdicaoManutencao() throws Exception {
        mockMvc.perform(get("/manutencoes/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("manutencao/form"))
                .andExpect(model().attributeExists("manutencao"))
                .andExpect(model().attributeExists("drones"))
                .andExpect(model().attributeExists("sensores"))
                .andExpect(model().attributeExists("sinalizacoes"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean
        public ManutencaoService manutencaoService() {
            return mock(ManutencaoService.class);
        }

        @Bean
        public DroneService droneService() {
            return mock(DroneService.class);
        }

        @Bean
        public SensorService sensorService() {
            return mock(SensorService.class);
        }

        @Bean
        public SinalizacaoService sinalizacaoService() {
            return mock(SinalizacaoService.class);
        }

        @Bean
        public UsuarioService usuarioService() {
            return mock(UsuarioService.class);
        }
    }
}

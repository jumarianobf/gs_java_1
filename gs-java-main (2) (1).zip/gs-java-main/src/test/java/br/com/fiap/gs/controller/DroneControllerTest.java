package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Drone;
import br.com.fiap.gs.service.DroneService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = DroneController.class)
@Import(DroneControllerTest.MockConfig.class)
class DroneControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private DroneService droneService;

    @BeforeEach
    void setUp() {
        Drone d = new Drone();
        d.setIdDrone(1L);
        d.setNome("X-Wing");

        when(droneService.listarTodos()).thenReturn(List.of(d));
        when(droneService.buscarPorId(1L)).thenReturn(d);
    }


    @Test
    @WithMockUser(roles = "ADMIN")
    void deveExibirFormularioNovoDrone_comAdmin() throws Exception {
        mockMvc.perform(get("/drone/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("drone/form"))
                .andExpect(model().attributeExists("drone"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void deveExibirFormularioEdicaoDrone_comAdmin() throws Exception {
        mockMvc.perform(get("/drone/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("drone/form"))
                .andExpect(model().attributeExists("drone"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean DroneService droneService() { return mock(DroneService.class); }
    }
}

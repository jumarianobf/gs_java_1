package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = UsuarioController.class)
@Import(UsuarioControllerTest.MockServiceConfig.class)
class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(1L);
        usuario.setNome("Julia");

        when(usuarioService.listarTodos()).thenReturn(List.of(usuario));
    }

    @Test
    @WithMockUser(username = "julia", roles = {"USER"})
    void deveListarUsuarios() throws Exception {
        mockMvc.perform(get("/usuarios"))
                .andExpect(status().isOk())
                .andExpect(view().name("usuario/lista"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @Test
    @WithMockUser(username = "julia", roles = {"USER"})
    void deveExibirFormularioRegistro() throws Exception {
        mockMvc.perform(get("/usuarios/registrar"))
                .andExpect(status().isOk())
                .andExpect(view().name("usuario/registrar"))
                .andExpect(model().attributeExists("usuario"));
    }


    @TestConfiguration
    static class MockServiceConfig {
        @Bean
        public UsuarioService usuarioService() {
            return mock(UsuarioService.class);
        }

        @Bean
        public PasswordEncoder passwordEncoder() {
            return mock(PasswordEncoder.class);
        }
    }
}

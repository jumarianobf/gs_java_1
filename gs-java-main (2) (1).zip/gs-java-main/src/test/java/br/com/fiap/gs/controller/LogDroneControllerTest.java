package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Drone;
import br.com.fiap.gs.model.LogDrone;
import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.service.DroneService;
import br.com.fiap.gs.service.LogDroneService;
import br.com.fiap.gs.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = LogDroneController.class)
@Import(LogDroneControllerTest.MockConfig.class)
class LogDroneControllerTest {

    @Autowired private MockMvc mockMvc;

    @Autowired private LogDroneService logDroneService;
    @Autowired private DroneService droneService;
    @Autowired private UsuarioService usuarioService;

    @BeforeEach
    void setup() {
        LogDrone log = new LogDrone();
        log.setIdLog(1L);
        log.setAcaoRealizada("Decolagem");

        when(logDroneService.listarTodos()).thenReturn(List.of(log));
        when(logDroneService.buscarPorId(1L)).thenReturn(log);
        when(droneService.listarTodos()).thenReturn(List.of(new Drone()));
        when(usuarioService.listarTodos()).thenReturn(List.of(new Usuario()));
    }


    @Test
    @WithMockUser(roles = "ADMIN")
    void deveExibirFormularioNovoLog_comAdmin() throws Exception {
        mockMvc.perform(get("/log-drone/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("logdrone/form"))
                .andExpect(model().attributeExists("logDrone"))
                .andExpect(model().attributeExists("drones"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void deveExibirFormularioEdicaoLog_comAdmin() throws Exception {
        mockMvc.perform(get("/log-drone/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("logdrone/form"))
                .andExpect(model().attributeExists("logDrone"))
                .andExpect(model().attributeExists("drones"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean public LogDroneService logDroneService() { return mock(LogDroneService.class); }
        @Bean public DroneService droneService() { return mock(DroneService.class); }
        @Bean public UsuarioService usuarioService() { return mock(UsuarioService.class); }
    }

}

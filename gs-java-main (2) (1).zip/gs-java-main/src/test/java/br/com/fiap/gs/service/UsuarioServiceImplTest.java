package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.repository.UsuarioRepository;
import br.com.fiap.gs.service.impl.UsuarioServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UsuarioServiceImplTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UsuarioServiceImpl usuarioService;

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        usuario = new Usuario();
        usuario.setIdUsuario(1L);
        usuario.setNome("Julia");
        usuario.setEmail("julia@email.com");
        usuario.setSenhaHash("senha123");
        usuario.setNivelAcesso("ADMIN");
        usuario.setStatus("ATIVO");
    }

    @Test
    void deveSalvarUsuarioComSucesso() {
        when(usuarioRepository.existsByEmail(usuario.getEmail())).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("senhaCodificada");
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        Usuario salvo = usuarioService.salvar(usuario);

        assertNotNull(salvo);
        assertEquals(usuario.getEmail(), salvo.getEmail());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), Optional.ofNullable(any()));
    }

    @Test
    void deveLancarExcecao_QuandoEmailJaExiste() {
        when(usuarioRepository.existsByEmail(usuario.getEmail())).thenReturn(true);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> usuarioService.salvar(usuario));

        assertEquals("Email já cadastrado no sistema.", exception.getMessage());
    }

    @Test
    void deveBuscarPorIdComSucesso() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

        Usuario encontrado = usuarioService.buscarPorId(1L);

        assertNotNull(encontrado);
        assertEquals("Julia", encontrado.getNome());
    }

    @Test
    void deveLancarExcecao_QuandoBuscarPorIdInexistente() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> usuarioService.buscarPorId(1L));
    }

}


package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.ConfigAlerta;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.ConfigAlertaService;
import br.com.fiap.gs.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = ConfigAlertaController.class)
@Import(ConfigAlertaControllerTest.MockConfig.class)
class ConfigAlertaControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ConfigAlertaService configAlertaService;
    @Autowired private AreaRiscoService areaRiscoService;
    @Autowired private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        ConfigAlerta config = new ConfigAlerta();
        config.setIdConfig(1L);
        config.setTipoAlerta("Temperatura");

        when(configAlertaService.listarTodos()).thenReturn(List.of(config));
        when(configAlertaService.buscarPorId(1L)).thenReturn(config);
        when(areaRiscoService.listarTodos()).thenReturn(List.of());
        when(usuarioService.listarTodos()).thenReturn(List.of());
    }



    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioNovo() throws Exception {
        mockMvc.perform(get("/config-alerta/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("config-alerta/form"))
                .andExpect(model().attributeExists("configAlerta"))
                .andExpect(model().attributeExists("areas"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioEdicao() throws Exception {
        mockMvc.perform(get("/config-alerta/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("config-alerta/form"))
                .andExpect(model().attributeExists("configAlerta"))
                .andExpect(model().attributeExists("areas"))
                .andExpect(model().attributeExists("usuarios"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean ConfigAlertaService configAlertaService() { return mock(ConfigAlertaService.class); }
        @Bean AreaRiscoService areaRiscoService() { return mock(AreaRiscoService.class); }
        @Bean UsuarioService usuarioService() { return mock(UsuarioService.class); }
    }
}

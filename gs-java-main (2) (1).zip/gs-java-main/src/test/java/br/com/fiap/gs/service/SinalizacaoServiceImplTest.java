package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.SinalizacaoEvent;
import br.com.fiap.gs.model.Sinalizacao;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.repository.SinalizacaoRepository;
import br.com.fiap.gs.service.impl.SinalizacaoServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SinalizacaoServiceImplTest {

    @Mock
    private SinalizacaoRepository sinalizacaoRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @InjectMocks
    private SinalizacaoServiceImpl sinalizacaoService;

    private Sinalizacao sinalizacao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        sinalizacao = new Sinalizacao();
        sinalizacao.setIdSinalizacao(1L);
        sinalizacao.setTipoSinalizacao("Placa");
        sinalizacao.setDescricao("Perigo de incêndio");
        sinalizacao.setStatus("ATIVO");
        sinalizacao.setDataInstalacao(LocalDateTime.now());
        sinalizacao.setArea(new AreaRisco());
    }

    @Test
    void deveSalvarSinalizacaoComSucesso() {
        when(sinalizacaoRepository.save(any(Sinalizacao.class))).thenReturn(sinalizacao);

        Sinalizacao salvo = sinalizacaoService.salvar(sinalizacao);

        assertNotNull(salvo);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(SinalizacaoEvent.class));
    }

    @Test
    void deveAtualizarSinalizacaoComSucesso() {
        when(sinalizacaoRepository.findById(1L)).thenReturn(Optional.of(sinalizacao));
        when(sinalizacaoRepository.save(any(Sinalizacao.class))).thenReturn(sinalizacao);

        Sinalizacao atualizada = new Sinalizacao();
        atualizada.setTipoSinalizacao("Sirene");
        atualizada.setDescricao("Zona de evacuação");
        atualizada.setStatus("INATIVO");
        atualizada.setDataInstalacao(LocalDateTime.now());
        atualizada.setArea(new AreaRisco());

        Sinalizacao resultado = sinalizacaoService.atualizar(1L, atualizada);

        assertEquals("Sirene", resultado.getTipoSinalizacao());
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(SinalizacaoEvent.class));
    }

    @Test
    void deveBuscarPorIdComSucesso() {
        when(sinalizacaoRepository.findById(1L)).thenReturn(Optional.of(sinalizacao));

        Sinalizacao encontrada = sinalizacaoService.buscarPorId(1L);

        assertNotNull(encontrada);
        assertEquals("Placa", encontrada.getTipoSinalizacao());
    }

    @Test
    void deveLancarExcecao_QuandoIdNaoExiste() {
        when(sinalizacaoRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> sinalizacaoService.buscarPorId(1L));
    }

    @Test
    void deveDeletarSinalizacaoComSucesso() {
        when(sinalizacaoRepository.findById(1L)).thenReturn(Optional.of(sinalizacao));

        sinalizacaoService.deletar(1L);

        verify(sinalizacaoRepository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(SinalizacaoEvent.class));
    }
}

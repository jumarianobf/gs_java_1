
package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.AlertaSensor;
import br.com.fiap.gs.service.AlertaSensorService;
import br.com.fiap.gs.service.AlertaService;
import br.com.fiap.gs.service.SensorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = AlertaSensorController.class)
@Import(AlertaSensorControllerTest.MockConfig.class)
class AlertaSensorControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private AlertaSensorService alertaSensorService;
    @Autowired private AlertaService alertaService;
    @Autowired private SensorService sensorService;

    @BeforeEach
    void setUp() {
        AlertaSensor alertaSensor = new AlertaSensor();
        alertaSensor.setIdAlertaSensor(1L);
        when(alertaSensorService.listarTodos()).thenReturn(List.of(alertaSensor));
        when(alertaSensorService.buscarPorId(1L)).thenReturn(alertaSensor);
        when(alertaService.listarTodos()).thenReturn(List.of());
        when(sensorService.listarTodos()).thenReturn(List.of());
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioNovo() throws Exception {
        mockMvc.perform(get("/alerta-sensor/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("alerta-sensor/form"))
                .andExpect(model().attributeExists("alertaSensor"))
                .andExpect(model().attributeExists("alertas"))
                .andExpect(model().attributeExists("sensores"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioEdicao() throws Exception {
        mockMvc.perform(get("/alerta-sensor/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("alerta-sensor/form"))
                .andExpect(model().attributeExists("alertaSensor"))
                .andExpect(model().attributeExists("alertas"))
                .andExpect(model().attributeExists("sensores"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean AlertaSensorService alertaSensorService() { return mock(AlertaSensorService.class); }
        @Bean AlertaService alertaService() { return mock(AlertaService.class); }
        @Bean SensorService sensorService() { return mock(SensorService.class); }
    }
}

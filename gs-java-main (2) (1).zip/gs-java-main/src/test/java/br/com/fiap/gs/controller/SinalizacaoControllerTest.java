package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Sinalizacao;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.service.SinalizacaoService;
import br.com.fiap.gs.service.AreaRiscoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = SinalizacaoController.class)
@Import(SinalizacaoControllerTest.MockConfig.class)
class SinalizacaoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private SinalizacaoService sinalizacaoService;

    @Autowired
    private AreaRiscoService areaRiscoService;

    @BeforeEach
    void setUp() {
        Sinalizacao s = new Sinalizacao();
        s.setIdSinalizacao(1L);
        s.setTipoSinalizacao("Placa");

        AreaRisco a = new AreaRisco();
        a.setIdArea(1L);
        a.setDescricao("Área teste");

        when(sinalizacaoService.listarTodos()).thenReturn(List.of(s));
        when(areaRiscoService.listarTodos()).thenReturn(List.of(a));
        when(sinalizacaoService.buscarPorId(1L)).thenReturn(s);
    }

    @Test
    @WithMockUser(roles = {"USER"})
    void deveListarSinalizacoes_comUsuarioAutenticado() throws Exception {
        mockMvc.perform(get("/sinalizacoes"))
                .andExpect(status().isOk())
                .andExpect(view().name("sinalizacao/lista"))
                .andExpect(model().attributeExists("sinalizacoes"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioNovaSinalizacao_comAdmin() throws Exception {
        mockMvc.perform(get("/sinalizacoes/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("sinalizacao/form"))
                .andExpect(model().attributeExists("sinalizacao"))
                .andExpect(model().attributeExists("areas"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioEdicaoSinalizacao_comAdmin() throws Exception {
        mockMvc.perform(get("/sinalizacoes/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("sinalizacao/form"))
                .andExpect(model().attributeExists("sinalizacao"))
                .andExpect(model().attributeExists("areas"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean
        public SinalizacaoService sinalizacaoService() {
            return mock(SinalizacaoService.class);
        }

        @Bean
        public AreaRiscoService areaRiscoService() {
            return mock(AreaRiscoService.class);
        }
    }
}

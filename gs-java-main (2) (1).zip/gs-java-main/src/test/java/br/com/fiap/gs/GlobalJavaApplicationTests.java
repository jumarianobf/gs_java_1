package br.com.fiap.gs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package br.com.fiap.gs.service;

import br.com.fiap.gs.messaging.LeituraSensorEvent;
import br.com.fiap.gs.model.LeituraSensor;
import br.com.fiap.gs.model.Sensor;
import br.com.fiap.gs.repository.LeituraSensorRepository;
import br.com.fiap.gs.service.impl.LeituraSensorImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LeituraSensorImplTest {

    @Mock
    private LeituraSensorRepository leituraSensorRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @InjectMocks
    private LeituraSensorImpl leituraSensorService;

    private LeituraSensor leitura;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        Sensor sensor = new Sensor();
        sensor.setIdSensor(1L);

        leitura = LeituraSensor.builder()
                .idLeitura(1L)
                .dataHora(LocalDateTime.now())
                .valorLeitura(32.5)
                .unidadeMedida("°C")
                .status("OK")
                .sensor(sensor)
                .build();
    }

    @Test
    void deveSalvarLeituraSensor() {
        when(leituraSensorRepository.save(leitura)).thenReturn(leitura);

        LeituraSensor salvo = leituraSensorService.salvar(leitura);

        assertNotNull(salvo);
        verify(leituraSensorRepository).save(leitura);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(LeituraSensorEvent.class));
    }

    @Test
    void deveAtualizarLeituraSensor() {
        when(leituraSensorRepository.findById(1L)).thenReturn(Optional.of(leitura));
        when(leituraSensorRepository.save(any())).thenReturn(leitura);

        LeituraSensor atualizado = leituraSensorService.atualizar(1L, leitura);

        assertNotNull(atualizado);
        verify(leituraSensorRepository).findById(1L);
        verify(leituraSensorRepository).save(leitura);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(LeituraSensorEvent.class));
    }

    @Test
    void deveDeletarLeituraSensor() {
        when(leituraSensorRepository.findById(1L)).thenReturn(Optional.of(leitura));

        leituraSensorService.deletar(1L);

        verify(leituraSensorRepository).deleteById(1L);
        verify(rabbitTemplate).convertAndSend(anyString(), anyString(), any(LeituraSensorEvent.class));
    }

    @Test
    void deveBuscarPorId() {
        when(leituraSensorRepository.findById(1L)).thenReturn(Optional.of(leitura));

        LeituraSensor encontrada = leituraSensorService.buscarPorId(1L);

        assertEquals(leitura.getIdLeitura(), encontrada.getIdLeitura());
        verify(leituraSensorRepository).findById(1L);
    }

    @Test
    void deveListarTodasLeituras() {
        leituraSensorService.listarTodos();
        verify(leituraSensorRepository).findAll();
    }

    @Test
    void deveLancarExcecaoSeLeituraNaoEncontrada() {
        when(leituraSensorRepository.findById(999L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> leituraSensorService.buscarPorId(999L));
        assertEquals("Leitura do sensor não encontrada", ex.getMessage());
    }
}

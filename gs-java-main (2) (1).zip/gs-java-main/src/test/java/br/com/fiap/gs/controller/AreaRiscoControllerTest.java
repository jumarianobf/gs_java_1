
package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.service.AreaRiscoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = AreaRiscoController.class)
@Import(AreaRiscoControllerTest.MockConfig.class)
class AreaRiscoControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private AreaRiscoService areaRiscoService;

    @BeforeEach
    void setUp() {
        AreaRisco area = new AreaRisco();
        area.setIdArea(1L);
        area.setNomeArea("Zona A");
        when(areaRiscoService.listarTodos()).thenReturn(List.of(area));
        when(areaRiscoService.buscarPorId(1L)).thenReturn(area);
    }

    @Test
    @WithMockUser(roles = {"USER"})
    void deveListarAreas() throws Exception {
        mockMvc.perform(get("/area-risco"))
                .andExpect(status().isOk())
                .andExpect(view().name("area-risco/lista"))
                .andExpect(model().attributeExists("areasRisco"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioNovo() throws Exception {
        mockMvc.perform(get("/area-risco/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("area-risco/form"))
                .andExpect(model().attributeExists("areaRisco"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    void deveExibirFormularioEdicao() throws Exception {
        mockMvc.perform(get("/area-risco/editar/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("area-risco/form"))
                .andExpect(model().attributeExists("areaRisco"));
    }

    @TestConfiguration
    static class MockConfig {
        @Bean AreaRiscoService areaRiscoService() { return mock(AreaRiscoService.class); }
    }
}

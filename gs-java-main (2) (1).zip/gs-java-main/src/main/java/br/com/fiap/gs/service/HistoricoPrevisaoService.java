package br.com.fiap.gs.service;

import br.com.fiap.gs.model.HistoricoPrevisao;

import java.util.List;

public interface HistoricoPrevisaoService {
    List<HistoricoPrevisao> listarTodos();
    HistoricoPrevisao buscarPorId(Long id);
    HistoricoPrevisao salvar(HistoricoPrevisao h);
    HistoricoPrevisao atualizar(Long id, HistoricoPrevisao h);
    void deletar(Long id);
}

package br.com.fiap.gs.messaging;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class DroneEventListener {

    @RabbitListener(queues = "fila.drone")
    public void receberEvento(DroneEvent evento) {
        System.out.println("📦 Evento de Drone recebido: " + evento.tipo() +
                " | ID: " + evento.id() + " | Nome: " + evento.nome());
    }
}

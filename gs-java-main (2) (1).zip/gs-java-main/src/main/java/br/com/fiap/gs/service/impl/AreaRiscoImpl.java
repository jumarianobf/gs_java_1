package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.AreaRiscoEvent;
import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.repository.AreaRiscoRepository;
import br.com.fiap.gs.service.AreaRiscoService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AreaRiscoImpl implements AreaRiscoService {

    private final AreaRiscoRepository repository;
    private final RabbitTemplate rabbitTemplate;

    public AreaRiscoImpl(AreaRiscoRepository repository, RabbitTemplate rabbitTemplate) {
        this.repository = repository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(AreaRiscoEvent.Tipo tipo, AreaRisco a) {
        AreaRiscoEvent evt = new AreaRiscoEvent(
                tipo,
                a.getIdArea(),
                a.getNomeArea(),
                a.getDescricao(),
                a.getLatitude(),
                a.getLongitude(),
                a.getStatus(),
                a.getRaioCobertura(),
                a.getDataCadastro()
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public AreaRisco salvar(AreaRisco a) {
        if (a.getDataCadastro() == null) {
            a.setDataCadastro(LocalDateTime.now());
        }

        AreaRisco salvo = repository.save(a);
        publishEvent(AreaRiscoEvent.Tipo.CRIADO, salvo);
        return salvo;
    }


    @Override
    public AreaRisco atualizar(Long id, AreaRisco a) {
        AreaRisco existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Área de risco não encontrada"));
        existente.setNomeArea(a.getNomeArea());
        existente.setDescricao(a.getDescricao());
        existente.setLatitude(a.getLatitude());
        existente.setLongitude(a.getLongitude());
        existente.setStatus(a.getStatus());
        existente.setRaioCobertura(a.getRaioCobertura());
        existente.setDataCadastro(a.getDataCadastro());
        AreaRisco atualizado = repository.save(existente);
        publishEvent(AreaRiscoEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        AreaRisco existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Área de risco não encontrada"));
        repository.deleteById(id);
        publishEvent(AreaRiscoEvent.Tipo.DELETADO, existente);
    }

    @Override
    public long contarPorStatus(String status) {
        return repository.countByStatus(status);
    }

    @Override
    public List<AreaRisco> ultimas(int limite) {
        return repository.findTop5ByOrderByDataCadastroDesc();
    }

    @Override
    public List<AreaRisco> listarTodos() {
        return repository.findAll();
    }

    @Override
    public AreaRisco buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Área de risco não encontrada"));
    }
}

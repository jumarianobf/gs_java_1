package br.com.fiap.gs.messaging;

public record AlertaSensorEvent(
        Tipo tipo,
        Long id,
        Double valorDisparo,
        Long idAlerta,
        String tipoSensor
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}
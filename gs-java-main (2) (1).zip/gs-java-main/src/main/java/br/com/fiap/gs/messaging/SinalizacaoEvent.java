package br.com.fiap.gs.messaging;

public record SinalizacaoEvent(
        Tipo tipo,
        Long id,
        String tipoSinalizacao,
        String descricao,
        String status
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}

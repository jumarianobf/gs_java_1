package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Manutencao;

import java.util.List;

public interface ManutencaoService {
    List<Manutencao> listarTodos();
    Manutencao buscarPorId(Long id);
    Manutencao salvar(Manutencao m);
    Manutencao atualizar(Long id, Manutencao m);
    void deletar(Long id);
}

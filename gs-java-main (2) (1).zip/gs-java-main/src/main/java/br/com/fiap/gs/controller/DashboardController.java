package br.com.fiap.gs.controller;

import br.com.fiap.gs.service.AlertaService;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.DroneService;
import br.com.fiap.gs.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private DroneService droneService;

    @Autowired
    private AreaRiscoService areaRiscoService;

    @Autowired
    private AlertaService alertaService;

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String exibirDashboard(Model model) {

        // Obter a lista de áreas de risco
        var areasRiscoList = areaRiscoService.listarTodos();

        // Quantidade total de missões (você pode ajustar se tiver service específico)
        long totalMissoes = areasRiscoList.size();

        // Missões concluídas (ex: status = "CONCLUIDA")
        long missoesConcluidas = areasRiscoList.stream()
                .filter(a -> "CONCLUIDA".equalsIgnoreCase(a.getStatus()))
                .count();

        // Drones ativos e em manutenção
        var dronesList = droneService.listarTodos();
        long dronesAtivos = dronesList.stream()
                .filter(d -> "ATIVO".equalsIgnoreCase(d.getStatus()))
                .count();

        long dronesManutencao = dronesList.stream()
                .filter(d -> "MANUTENCAO".equalsIgnoreCase(d.getStatus()))
                .count();

        // Lista de drones em manutenção para exibição na lista inferior
        var listaManutencao = dronesList.stream()
                .filter(d -> "MANUTENCAO".equalsIgnoreCase(d.getStatus()))
                .toList();

        // JSON com dados dos drones para o mapa (nome, status, latitude, longitude, bateria, idDrone)
        String dronesJson = dronesList.stream()
                .map(d -> String.format(
                        "{\"idDrone\":%d, \"nome\":\"%s\", \"status\":\"%s\", \"latitude\":%s, \"longitude\":%s, \"bateria\":%d}",
                        d.getIdDrone(), d.getNome(), d.getStatus(), d.getLatitude(), d.getLongitude(), d.getBateria() != null ? d.getBateria() : 0))
                .collect(java.util.stream.Collectors.joining(",", "[", "]"));

        // Atributos no model para Thymeleaf
        model.addAttribute("totalMissoes", totalMissoes);
        model.addAttribute("missoesConcluidas", missoesConcluidas);
        model.addAttribute("dronesAtivosCount", dronesAtivos);
        model.addAttribute("dronesManutencao", dronesManutencao);
        model.addAttribute("drones", listaManutencao);
        model.addAttribute("dronesJson", dronesJson);
        model.addAttribute("areasRisco", areasRiscoList);

        return "dashboard/index";
    }
}
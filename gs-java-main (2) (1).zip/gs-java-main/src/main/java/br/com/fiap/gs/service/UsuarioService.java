package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Usuario;

import java.util.List;

public interface UsuarioService {
    List<Usuario> listarTodos();
    Usuario buscarPorId(Long id);
    Usuario buscarPorEmail(String email);
    Usuario salvar(Usuario u);
    Usuario atualizar(Long id, Usuario u);
    void deletar(Long id);

    List<Usuario> buscarPorStatus(String status);
    List<Usuario> buscarPorNivelAcesso(String nivelAcesso);
    Long contarUsuariosAtivos();
    Long contarPorNivel(String nivel);

}

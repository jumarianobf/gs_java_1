package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record UsuarioEvent(
        Tipo tipo,
        Long id,
        String nome,
        String email,
        String senhaHash,
        String nivelAcesso,
        String status,
        LocalDateTime dataCriacao
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}

package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.AlertaEvent;
import br.com.fiap.gs.model.Alerta;
import br.com.fiap.gs.repository.AlertaRepository;
import br.com.fiap.gs.service.AlertaService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlertaImpl implements AlertaService {

    private final AlertaRepository repository;
    private final RabbitTemplate rabbitTemplate;

    public AlertaImpl(AlertaRepository repository, RabbitTemplate rabbitTemplate) {
        this.repository = repository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(AlertaEvent.Tipo tipo, Alerta a) {
        AlertaEvent evt = new AlertaEvent(
                tipo,
                a.getIdAlerta(),
                a.getTipoAlerta(),
                a.getStatus(),
                a.getGravidade(),
                a.getDescricao(),
                a.getArea().getIdArea(),
                a.getDrone() != null ? a.getDrone().getIdDrone() : null,
                a.getUsuario() != null ? a.getUsuario().getIdUsuario() : null
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<Alerta> listarTodos() {
        return repository.findAll();
    }

    @Override
    public Alerta buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Alerta não encontrado"));
    }

    @Override
    public Alerta salvar(Alerta a) {
        Alerta salvo = repository.save(a);
        publishEvent(AlertaEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public Alerta atualizar(Long id, Alerta a) {
        Alerta existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Alerta não encontrado"));
        existente.setTipoAlerta(a.getTipoAlerta());
        existente.setStatus(a.getStatus());
        existente.setGravidade(a.getGravidade());
        existente.setDescricao(a.getDescricao());
        existente.setArea(a.getArea());
        existente.setDrone(a.getDrone());
        existente.setUsuario(a.getUsuario());
        Alerta atualizado = repository.save(existente);
        publishEvent(AlertaEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        Alerta existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Alerta não encontrado"));
        repository.deleteById(id);
        publishEvent(AlertaEvent.Tipo.DELETADO, existente);
    }

    @Override
    public long contarPendentes() {
        return repository.countPendentes();
    }

    @Override
    public List<Alerta> ultimos(int limite) {
        return repository.findTop5ByOrderByDataHoraDesc();
    }


}

package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record ManutencaoEvent(
        Tipo tipoManutencao,
        Long id,
        String tipo,
        LocalDateTime dataAgendada,
        LocalDateTime dataConclusao,
        String status,
        String observacoes,
        Long idDrone,
        Long idSensor,
        Long idSinalizacao,
        Long idUsuario
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}

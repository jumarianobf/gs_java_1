package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record HistoricoPrevisaoEvent(
        Tipo tipo,
        Long id,
        String tipoEvento,
        LocalDateTime dataPrevisao,
        Double probabilidade,
        String nivelRisco,
        String descricao,
        String acaoRecomendada,
        Long idAreaRisco,
        String nomeArea
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}

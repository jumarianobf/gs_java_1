package br.com.fiap.gs.repository;

import br.com.fiap.gs.model.Drone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DroneRepository extends JpaRepository<Drone, Long> {
    @Query("SELECT COUNT(d) FROM Drone d WHERE d.status = 'ATIVO'")
    long countAtivos();
}

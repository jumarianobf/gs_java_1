package br.com.fiap.gs.service;

import br.com.fiap.gs.model.AlertaSensor;

import java.util.List;

public interface AlertaSensorService {
    List<AlertaSensor> listarTodos();
    AlertaSensor buscarPorId(Long id);
    AlertaSensor salvar(AlertaSensor a);
    AlertaSensor atualizar(Long id, AlertaSensor a);
    void deletar(Long id);
}

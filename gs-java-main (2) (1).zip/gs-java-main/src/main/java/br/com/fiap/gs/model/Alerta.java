package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Alerta")
public class Alerta {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_alerta")
    @SequenceGenerator(name = "seq_alerta", sequenceName = "seq_alerta", allocationSize = 1)
    @Column(name = "id_alerta")
    private Long idAlerta;

    @Column(name = "tipo_alerta", length = 20)
    private String tipoAlerta;

    @Column(name = "data_hora")
    private LocalDateTime dataHora;

    @Column(name = "status", length = 20)
    private String status;

    @Column(name = "gravidade", length = 10)
    private String gravidade;

    @Lob
    @Column(name = "descricao")
    private String descricao;

    @ManyToOne
    @JoinColumn(name = "id_area", nullable = false)
    private AreaRisco area;

    @ManyToOne
    @JoinColumn(name = "id_drone")
    private Drone drone;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;
}


package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record AreaRiscoEvent(
        Tipo tipo,
        Long id,
        String nomeArea,
        String descricao,
        Double latitude,
        Double longitude,
        String status,
        Double raioCobertura,
        LocalDateTime dataCadastro
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}

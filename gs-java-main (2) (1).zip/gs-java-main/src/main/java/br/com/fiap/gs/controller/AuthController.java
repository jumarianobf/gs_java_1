package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
public class AuthController {

    private UsuarioService usuarioService;

    @GetMapping("/login")
    public String login(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout,
            @RequestParam(value = "expired", required = false) String expired,
            Model model
    ) {
        if (error != null) {
            model.addAttribute("error", "Email ou senha incorretos.");
        }

        if (logout != null) {
            model.addAttribute("logout", "Logout realizado com sucesso!");
        }

        if (expired != null) {
            model.addAttribute("expired", "Sua sessão expirou. Faça login novamente.");
        }

        return "acesso/login";
    }

    @GetMapping("/access-denied")
    public String accessDenied(Model model) {
        model.addAttribute("titulo", "Acesso Negado");
        return "acesso/accessDenied";
    }

    @GetMapping("/")
    public String home() {
        return "home/home";
    }
}

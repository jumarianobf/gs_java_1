package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.SinalizacaoEvent;
import br.com.fiap.gs.model.Sinalizacao;
import br.com.fiap.gs.repository.SinalizacaoRepository;
import br.com.fiap.gs.service.SinalizacaoService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SinalizacaoServiceImpl implements SinalizacaoService {

    private final SinalizacaoRepository sinalizacaoRepository;
    private final RabbitTemplate rabbitTemplate;

    public SinalizacaoServiceImpl(SinalizacaoRepository sinalizacaoRepository, RabbitTemplate rabbitTemplate) {
        this.sinalizacaoRepository = sinalizacaoRepository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(SinalizacaoEvent.Tipo tipo, Sinalizacao s) {
        SinalizacaoEvent evt = new SinalizacaoEvent(
                tipo,
                s.getIdSinalizacao(),
                s.getTipoSinalizacao(),
                s.getDescricao(),
                s.getStatus()
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<Sinalizacao> listarTodos() {
        return sinalizacaoRepository.findAll();
    }

    @Override
    public Sinalizacao buscarPorId(Long id) {
        return sinalizacaoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sinalização não encontrada"));
    }

    @Override
    public Sinalizacao salvar(Sinalizacao s) {
        Sinalizacao salvo = sinalizacaoRepository.save(s);
        publishEvent(SinalizacaoEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public Sinalizacao atualizar(Long id, Sinalizacao s) {
        Sinalizacao existente = sinalizacaoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sinalização não encontrada"));
        existente.setTipoSinalizacao(s.getTipoSinalizacao());
        existente.setDescricao(s.getDescricao());
        existente.setStatus(s.getStatus());
        existente.setDataInstalacao(s.getDataInstalacao());
        existente.setArea(s.getArea());
        Sinalizacao atualizado = sinalizacaoRepository.save(existente);
        publishEvent(SinalizacaoEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        Sinalizacao s = buscarPorId(id);
        sinalizacaoRepository.deleteById(id);
        publishEvent(SinalizacaoEvent.Tipo.DELETADO, s);
    }
}

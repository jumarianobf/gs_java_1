package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.*;
import br.com.fiap.gs.model.*;
import br.com.fiap.gs.repository.*;
import br.com.fiap.gs.service.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManutencaoImpl implements ManutencaoService {

    private final ManutencaoRepository manutencaoRepository;
    private final RabbitTemplate rabbitTemplate;

    public ManutencaoImpl(ManutencaoRepository manutencaoRepository, RabbitTemplate rabbitTemplate) {
        this.manutencaoRepository = manutencaoRepository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(ManutencaoEvent.Tipo tipo, Manutencao m) {
        ManutencaoEvent evt = new ManutencaoEvent(
                tipo,
                m.getIdManutencao(),
                m.getTipo(),
                m.getDataAgendada(),
                m.getDataConclusao(),
                m.getStatus(),
                m.getObservacoes(),
                m.getDrone() != null ? m.getDrone().getIdDrone() : null,
                m.getSensor() != null ? m.getSensor().getIdSensor() : null,
                m.getSinalizacao() != null ? m.getSinalizacao().getIdSinalizacao() : null,
                m.getUsuario() != null ? m.getUsuario().getIdUsuario() : null
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<Manutencao> listarTodos() {
        return manutencaoRepository.findAll();
    }

    @Override
    public Manutencao buscarPorId(Long id) {
        return manutencaoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Manutenção não encontrada"));
    }

    @Override
    public Manutencao salvar(Manutencao m) {
        Manutencao salvo = manutencaoRepository.save(m);
        publishEvent(ManutencaoEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public Manutencao atualizar(Long id, Manutencao m) {
        Manutencao existente = buscarPorId(id);
        existente.setTipo(m.getTipo());
        existente.setDataAgendada(m.getDataAgendada());
        existente.setDataConclusao(m.getDataConclusao());
        existente.setStatus(m.getStatus());
        existente.setObservacoes(m.getObservacoes());
        existente.setDrone(m.getDrone());
        existente.setSensor(m.getSensor());
        existente.setSinalizacao(m.getSinalizacao());
        existente.setUsuario(m.getUsuario());
        Manutencao atualizado = manutencaoRepository.save(existente);
        publishEvent(ManutencaoEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        Manutencao existente = buscarPorId(id);
        manutencaoRepository.deleteById(id);
        publishEvent(ManutencaoEvent.Tipo.DELETADO, existente);
    }
}

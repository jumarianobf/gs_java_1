package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.*;
import br.com.fiap.gs.model.*;
import br.com.fiap.gs.repository.*;
import br.com.fiap.gs.service.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LogDroneImpl implements LogDroneService {

    private final LogDroneRepository logDroneRepository;
    private final RabbitTemplate rabbitTemplate;

    public LogDroneImpl(LogDroneRepository logDroneRepository, RabbitTemplate rabbitTemplate) {
        this.logDroneRepository = logDroneRepository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(LogDroneEvent.Tipo tipo, LogDrone l) {
        LogDroneEvent evt = new LogDroneEvent(
                tipo,
                l.getIdLog(),
                l.getDataHora(),
                l.getAcaoRealizada(),
                l.getDescricao(),
                l.getLatitude(),
                l.getLongitude(),
                l.getStatus(),
                l.getDrone() != null ? l.getDrone().getIdDrone() : null,
                l.getUsuario() != null ? l.getUsuario().getIdUsuario() : null
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<LogDrone> listarTodos() {
        return logDroneRepository.findAll();
    }

    @Override
    public LogDrone buscarPorId(Long id) {
        return logDroneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Log do drone não encontrado"));
    }

    @Override
    public LogDrone salvar(LogDrone l) {
        LogDrone salvo = logDroneRepository.save(l);
        publishEvent(LogDroneEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public LogDrone atualizar(Long id, LogDrone l) {
        LogDrone existente = buscarPorId(id);
        existente.setDataHora(l.getDataHora());
        existente.setAcaoRealizada(l.getAcaoRealizada());
        existente.setDescricao(l.getDescricao());
        existente.setLatitude(l.getLatitude());
        existente.setLongitude(l.getLongitude());
        existente.setStatus(l.getStatus());
        existente.setDrone(l.getDrone());
        existente.setUsuario(l.getUsuario());
        LogDrone atualizado = logDroneRepository.save(existente);
        publishEvent(LogDroneEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        LogDrone existente = buscarPorId(id);
        logDroneRepository.deleteById(id);
        publishEvent(LogDroneEvent.Tipo.DELETADO, existente);
    }
}
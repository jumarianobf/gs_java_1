package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Sinalizacao;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.SinalizacaoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/sinalizacoes")
public class SinalizacaoController {

    private final SinalizacaoService sinalizacaoService;
    private final AreaRiscoService areaRiscoService;

    @Autowired
    public SinalizacaoController(SinalizacaoService sinalizacaoService, AreaRiscoService areaRiscoService) {
        this.sinalizacaoService = sinalizacaoService;
        this.areaRiscoService = areaRiscoService;
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listarSinalizacoes(Model model) {
        List<Sinalizacao> lista = sinalizacaoService.listarTodos();
        model.addAttribute("sinalizacoes", lista);
        return "sinalizacao/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novaSinalizacao(Model model) {
        model.addAttribute("sinalizacao", new Sinalizacao());
        model.addAttribute("areas", areaRiscoService.listarTodos());
        return "sinalizacao/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvarSinalizacao(
            @Valid @ModelAttribute("sinalizacao") Sinalizacao sinalizacao,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            model.addAttribute("areas", areaRiscoService.listarTodos());
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "sinalizacao/form";
        }

        try {
            sinalizacao.setDataInstalacao(LocalDateTime.now());
            sinalizacaoService.salvar(sinalizacao);
            redirectAttributes.addFlashAttribute("sucesso", "Sinalização cadastrada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "sinalizacao/form";
        }

        return "redirect:/sinalizacoes";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editarSinalizacao(@PathVariable Long id, Model model) {
        try {
            Sinalizacao sinalizacao = sinalizacaoService.buscarPorId(id);
            model.addAttribute("sinalizacao", sinalizacao);
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "sinalizacao/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/sinalizacoes";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizarSinalizacao(
            @PathVariable Long id,
            @Valid @ModelAttribute("sinalizacao") Sinalizacao sinalizacao,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            model.addAttribute("areas", areaRiscoService.listarTodos());
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "sinalizacao/form";
        }

        try {
            sinalizacaoService.atualizar(id, sinalizacao);
            redirectAttributes.addFlashAttribute("sucesso", "Sinalização atualizada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "sinalizacao/form";
        }

        return "redirect:/sinalizacoes";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletarSinalizacao(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            sinalizacaoService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Sinalização removida com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/sinalizacoes";
    }
}

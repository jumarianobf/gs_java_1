package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.AreaRisco;
import br.com.fiap.gs.service.AreaRiscoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/area-risco")
public class AreaRiscoController {

    @Autowired
    private AreaRiscoService areaRiscoService;

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listar(Model model) {
        List<AreaRisco> lista = areaRiscoService.listarTodos();
        model.addAttribute("areasRisco", lista);
        return "area-risco/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("areaRisco", new AreaRisco());
        return "area-risco/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("areaRisco") AreaRisco areaRisco,
                         BindingResult result,
                         RedirectAttributes redirectAttributes,
                         Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "area-risco/form";
        }

        try {
            areaRiscoService.salvar(areaRisco);
            redirectAttributes.addFlashAttribute("sucesso", "Área de risco salva com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "area-risco/form";
        }

        return "redirect:/area-risco";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        try {
            AreaRisco area = areaRiscoService.buscarPorId(id);
            model.addAttribute("areaRisco", area);
            return "area-risco/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/area-risco";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizar(@PathVariable Long id,
                            @Valid @ModelAttribute("areaRisco") AreaRisco areaRisco,
                            BindingResult result,
                            RedirectAttributes redirectAttributes,
                            Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "area-risco/form";
        }

        try {
            areaRiscoService.atualizar(id, areaRisco);
            redirectAttributes.addFlashAttribute("sucesso", "Área de risco atualizada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "area-risco/form";
        }

        return "redirect:/area-risco";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletar(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            areaRiscoService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Área de risco removida com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/area-risco";
    }
}

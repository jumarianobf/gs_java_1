package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record LeituraSensorEvent(
        Tipo tipo,
        Long id,
        LocalDateTime dataHora,
        Double valorLeitura,
        String unidadeMedida,
        String status,
        Long idSensor
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}


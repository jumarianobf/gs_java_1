package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "LogDrone")
public class LogDrone {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_log_drone")
    @SequenceGenerator(name = "seq_log_drone", sequenceName = "seq_log_drone", allocationSize = 1)
    @Column(name = "id_log")
    private Long idLog;

    @Column(name = "data_hora")
    private LocalDateTime dataHora;

    @Column(name = "acao_realizada", length = 30)
    private String acaoRealizada;

    @Column(name = "descricao")
    private String descricao;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "status", length = 20)
    private String status;

    @ManyToOne
    @JoinColumn(name = "id_drone", nullable = false)
    private Drone drone;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;
}
package br.com.fiap.gs.repository;

import br.com.fiap.gs.model.Alerta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AlertaRepository extends JpaRepository<Alerta, Long> {
    @Query("SELECT COUNT(a) FROM Alerta a WHERE a.status = 'PENDENTE'")
    long countPendentes();

    @Query("SELECT a FROM Alerta a ORDER BY a.dataHora DESC")
    List<Alerta> findTop5ByOrderByDataHoraDesc();

}

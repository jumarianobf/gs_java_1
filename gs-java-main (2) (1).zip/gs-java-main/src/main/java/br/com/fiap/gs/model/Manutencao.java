package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Manutencao")
public class Manutencao {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_manutencao")
    @SequenceGenerator(name = "seq_manutencao", sequenceName = "seq_manutencao", allocationSize = 1)
    @Column(name = "id_manutencao")
    private Long idManutencao;

    @Column(name = "tipo", length = 20)
    private String tipo;

    @Column(name = "data_agendada", nullable = false)
    private LocalDateTime dataAgendada;

    @Column(name = "data_conclusao")
    private LocalDateTime dataConclusao;

    @Column(name = "status")
    private String status;

    @Lob
    @Column(name = "observacoes")
    private String observacoes;

    @ManyToOne
    @JoinColumn(name = "id_drone")
    private Drone drone;

    @ManyToOne
    @JoinColumn(name = "id_sensor")
    private Sensor sensor;

    @ManyToOne
    @JoinColumn(name = "id_sinalizacao")
    private Sinalizacao sinalizacao;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;
}

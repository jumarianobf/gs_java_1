package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.AlertaSensor;
import br.com.fiap.gs.service.AlertaSensorService;
import br.com.fiap.gs.service.AlertaService;
import br.com.fiap.gs.service.SensorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/alerta-sensor")
public class AlertaSensorController {

    @Autowired
    private AlertaSensorService alertaSensorService;

    @Autowired
    private AlertaService alertaService;

    @Autowired
    private SensorService sensorService;

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listar(Model model) {
        List<AlertaSensor> lista = alertaSensorService.listarTodos();
        model.addAttribute("alertasSensor", lista);
        return "alerta-sensor/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("alertaSensor", new AlertaSensor());
        carregarRelacionamentos(model);
        return "alerta-sensor/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("alertaSensor") AlertaSensor alertaSensor,
                         BindingResult result,
                         RedirectAttributes redirectAttributes,
                         Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            carregarRelacionamentos(model);
            return "alerta-sensor/form";
        }

        try {
            alertaSensorService.salvar(alertaSensor);
            redirectAttributes.addFlashAttribute("sucesso", "Associação de alerta com sensor salva com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "alerta-sensor/form";
        }

        return "redirect:/alerta-sensor";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        try {
            AlertaSensor alertaSensor = alertaSensorService.buscarPorId(id);
            model.addAttribute("alertaSensor", alertaSensor);
            carregarRelacionamentos(model);
            return "alerta-sensor/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/alerta-sensor";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizar(@PathVariable Long id,
                            @Valid @ModelAttribute("alertaSensor") AlertaSensor alertaSensor,
                            BindingResult result,
                            RedirectAttributes redirectAttributes,
                            Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            carregarRelacionamentos(model);
            return "alerta-sensor/form";
        }

        try {
            alertaSensorService.atualizar(id, alertaSensor);
            redirectAttributes.addFlashAttribute("sucesso", "Associação atualizada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "alerta-sensor/form";
        }

        return "redirect:/alerta-sensor";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletar(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            alertaSensorService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Associação removida com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/alerta-sensor";
    }

    private void carregarRelacionamentos(Model model) {
        model.addAttribute("alertas", alertaService.listarTodos());
        model.addAttribute("sensores", sensorService.listarTodos());
    }
}

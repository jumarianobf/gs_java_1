package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.HistoricoPrevisao;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.HistoricoPrevisaoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/historico-previsao")
public class HistoricoPrevisaoController {

    private final HistoricoPrevisaoService historicoService;
    private final AreaRiscoService areaRiscoService;

    @Autowired
    public HistoricoPrevisaoController(HistoricoPrevisaoService historicoService, AreaRiscoService areaRiscoService) {
        this.historicoService = historicoService;
        this.areaRiscoService = areaRiscoService;
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listarHistorico(Model model) {
        List<HistoricoPrevisao> historico = historicoService.listarTodos();
        model.addAttribute("historicos", historico);
        return "historicoprevisao/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novoHistorico(Model model) {
        model.addAttribute("historicoPrevisao", new HistoricoPrevisao());
        model.addAttribute("areas", areaRiscoService.listarTodos());
        return "historicoprevisao/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvarHistorico(@Valid @ModelAttribute("historicoPrevisao") HistoricoPrevisao historico,
                                  BindingResult result,
                                  RedirectAttributes redirectAttributes,
                                  Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "historicoprevisao/form";
        }

        try {
            historicoService.salvar(historico);
            redirectAttributes.addFlashAttribute("sucesso", "Histórico salvo com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "historicoprevisao/form";
        }

        return "redirect:/historico-previsao";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editarHistorico(@PathVariable Long id, Model model) {
        try {
            HistoricoPrevisao historico = historicoService.buscarPorId(id);
            model.addAttribute("historicoPrevisao", historico);
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "historicoprevisao/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/historico-previsao";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizarHistorico(@PathVariable Long id,
                                     @Valid @ModelAttribute("historicoPrevisao") HistoricoPrevisao historico,
                                     BindingResult result,
                                     RedirectAttributes redirectAttributes,
                                     Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "historicoprevisao/form";
        }

        try {
            historicoService.atualizar(id, historico);
            redirectAttributes.addFlashAttribute("sucesso", "Histórico atualizado com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "historicoprevisao/form";
        }

        return "redirect:/historico-previsao";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletarHistorico(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            historicoService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Histórico removido com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/historico-previsao";
    }
}

package br.com.fiap.gs.repository;

import br.com.fiap.gs.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByEmail(String email);

    boolean existsByEmail(String email);

    @Query("SELECT u FROM Usuario u WHERE u.status = :status")
    List<Usuario> findByStatus(@Param("status") String status);

    @Query("SELECT u FROM Usuario u WHERE u.nivelAcesso = :nivelAcesso")
    List<Usuario> findByNivelAcesso(@Param("nivelAcesso") String nivelAcesso);

    @Query("SELECT u FROM Usuario u WHERE u.nome LIKE %:nome% OR u.email LIKE %:email%")
    List<Usuario> findByNomeOrEmail(@Param("nome") String nome, @Param("email") String email);

    @Query("SELECT COUNT(u) FROM Usuario u WHERE u.status = 'ATIVO'")
    Long countActiveUsers();

    @Query("SELECT COUNT(u) FROM Usuario u WHERE u.nivelAcesso = :nivel")
    Long countByNivelAcesso(@Param("nivel") String nivel);
}

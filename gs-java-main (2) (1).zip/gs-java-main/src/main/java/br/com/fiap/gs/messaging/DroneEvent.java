package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record DroneEvent(
        Tipo tipo,
        Long id,
        String nome,
        String modelo,
        String status,
        Double latitude,
        Double longitude,
        Integer bateria,
        Double capacidadeCarga,
        LocalDateTime dataUltimaManutencao,
        String horarioOperacao,
        LocalDateTime dataCadastro
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}

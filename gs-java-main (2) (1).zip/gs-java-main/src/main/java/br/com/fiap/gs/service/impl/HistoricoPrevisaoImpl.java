package br.com.fiap.gs.service.impl;


import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.HistoricoPrevisaoEvent;
import br.com.fiap.gs.model.HistoricoPrevisao;
import br.com.fiap.gs.repository.HistoricoPrevisaoRepository;
import br.com.fiap.gs.service.HistoricoPrevisaoService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HistoricoPrevisaoImpl implements HistoricoPrevisaoService {

    private final HistoricoPrevisaoRepository repository;
    private final RabbitTemplate rabbitTemplate;

    public HistoricoPrevisaoImpl(HistoricoPrevisaoRepository repository, RabbitTemplate rabbitTemplate) {
        this.repository = repository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(HistoricoPrevisaoEvent.Tipo tipo, HistoricoPrevisao h) {
        HistoricoPrevisaoEvent evt = new HistoricoPrevisaoEvent(
                tipo,
                h.getIdPrevisao(),
                h.getTipoEvento(),
                h.getDataPrevisao(),
                h.getProbabilidade(),
                h.getNivelRisco(),
                h.getDescricao(),
                h.getAcaoRecomendada(),
                h.getArea().getIdArea(),
                h.getArea().getNomeArea()
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<HistoricoPrevisao> listarTodos() {
        return repository.findAll();
    }

    @Override
    public HistoricoPrevisao buscarPorId(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Histórico de previsão não encontrado"));
    }

    @Override
    public HistoricoPrevisao salvar(HistoricoPrevisao h) {
        HistoricoPrevisao salvo = repository.save(h);
        publishEvent(HistoricoPrevisaoEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public HistoricoPrevisao atualizar(Long id, HistoricoPrevisao h) {
        HistoricoPrevisao existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Histórico de previsão não encontrado"));
        existente.setTipoEvento(h.getTipoEvento());
        existente.setDataPrevisao(h.getDataPrevisao());
        existente.setProbabilidade(h.getProbabilidade());
        existente.setNivelRisco(h.getNivelRisco());
        existente.setDescricao(h.getDescricao());
        existente.setAcaoRecomendada(h.getAcaoRecomendada());
        existente.setArea(h.getArea());
        HistoricoPrevisao atualizado = repository.save(existente);
        publishEvent(HistoricoPrevisaoEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        HistoricoPrevisao existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Histórico de previsão não encontrado"));
        repository.deleteById(id);
        publishEvent(HistoricoPrevisaoEvent.Tipo.DELETADO, existente);
    }
}


package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "LeituraSensor")
public class LeituraSensor {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_leitura_sensor")
    @SequenceGenerator(name = "seq_leitura_sensor", sequenceName = "seq_leitura_sensor", allocationSize = 1)
    @Column(name = "id_leitura")
    private Long idLeitura;

    @Column(name = "data_hora")
    private LocalDateTime dataHora;

    @Column(name = "valor_leitura", nullable = false)
    private Double valorLeitura;

    @Column(name = "unidade_medida", length = 10, nullable = false)
    private String unidadeMedida;

    @Column(name = "status", length = 10)
    private String status;

    @ManyToOne
    @JoinColumn(name = "id_sensor")
    private Sensor sensor;
}
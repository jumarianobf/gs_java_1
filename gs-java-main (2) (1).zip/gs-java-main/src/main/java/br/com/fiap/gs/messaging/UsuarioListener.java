package br.com.fiap.gs.messaging;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class UsuarioListener {

    @RabbitListener(queues = "fila.usuario")
    public void processarEventoUsuario(UsuarioEvent evento) {
        switch (evento.tipo()) {
            case CRIADO -> System.out.printf("[RabbitMQ] Novo usuário criado: %s (%s)%n", evento.nome(), evento.email());
            case ATUALIZADO -> System.out.printf("[RabbitMQ] Usuário atualizado: %s (%s)%n", evento.nome(), evento.email());
            case DELETADO -> System.out.printf("[RabbitMQ] Usuário deletado: ID %d (%s)%n", evento.id(), evento.nome());
        }
    }
}

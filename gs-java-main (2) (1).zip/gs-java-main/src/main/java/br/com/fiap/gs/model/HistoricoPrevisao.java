package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "HistoricoPrevisao")
public class HistoricoPrevisao {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_historico_previsao")
    @SequenceGenerator(name = "seq_historico_previsao", sequenceName = "seq_historico_previsao", allocationSize = 1)
    @Column(name = "id_previsao")
    private Long idPrevisao;

    @Column(name = "tipo_evento", length = 20)
    private String tipoEvento;

    @Column(name = "data_previsao")
    private LocalDateTime dataPrevisao;

    @Column(name = "probabilidade")
    private Double probabilidade;

    @Column(name = "nivel_risco", length = 10)
    private String nivelRisco;

    @Lob
    @Column(name = "descricao")
    private String descricao;

    @Lob
    @Column(name = "acao_recomendada")
    private String acaoRecomendada;

    @ManyToOne
    @JoinColumn(name = "id_area", nullable = false)
    private AreaRisco area;
}

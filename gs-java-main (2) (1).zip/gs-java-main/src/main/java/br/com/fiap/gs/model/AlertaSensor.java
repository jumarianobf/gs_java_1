package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "AlertaSensor")
public class AlertaSensor {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_alerta_sensor")
    @SequenceGenerator(name = "seq_alerta_sensor", sequenceName = "seq_alerta_sensor", allocationSize = 1)
    @Column(name = "id_alerta_sensor")
    private Long idAlertaSensor;

    @Column(name = "valor_disparo")
    private Double valorDisparo;

    @ManyToOne
    @JoinColumn(name = "id_alerta", nullable = false)
    private Alerta alerta;

    @ManyToOne
    @JoinColumn(name = "id_sensor", nullable = false)
    private Sensor sensor;
}

package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Alerta;

import java.util.List;

public interface AlertaService {
    List<Alerta> listarTodos();
    Alerta buscarPorId(Long id);
    Alerta salvar(Alerta a);
    Alerta atualizar(Long id, Alerta a);
    void deletar(Long id);
    long contarPendentes();
    List<Alerta> ultimos(int limite);

}

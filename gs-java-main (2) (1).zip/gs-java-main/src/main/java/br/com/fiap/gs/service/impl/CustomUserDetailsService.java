package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        System.out.println("Tentando carregar usuário por email: " + email);

        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> {
                    System.out.println("Usuário não encontrado: " + email);
                    return new UsernameNotFoundException("Usuário não encontrado: " + email);
                });

        System.out.println("Usuário encontrado: " + usuario.getEmail());
        System.out.println("Status do usuário: " + usuario.getStatus());
        System.out.println("Hash da senha: " + usuario.getSenhaHash());

        if (!"ATIVO".equals(usuario.getStatus())) {
            System.out.println("Usuário inativo: " + email);
            throw new UsernameNotFoundException("Usuário inativo: " + email);
        }
        return User.builder()
                .username(usuario.getEmail())
                .password(usuario.getSenhaHash())
                .authorities(getAuthorities(usuario))
                .disabled(false)
                .build();
    }


    private Collection<? extends GrantedAuthority> getAuthorities(Usuario usuario) {
        List<GrantedAuthority> authorities = new ArrayList<>();

        // Adicionar role baseado no nível de acesso
        authorities.add(new SimpleGrantedAuthority("ROLE_" + usuario.getNivelAcesso()));

        // Adicionar permissões específicas baseadas no role
        switch (usuario.getNivelAcesso()) {
            case "ADMIN":
                authorities.add(new SimpleGrantedAuthority("PERM_USER_CREATE"));
                authorities.add(new SimpleGrantedAuthority("PERM_USER_UPDATE"));
                authorities.add(new SimpleGrantedAuthority("PERM_USER_DELETE"));
                authorities.add(new SimpleGrantedAuthority("PERM_SYSTEM_CONFIG"));
                // Fall through para incluir permissões de OPERATOR
            case "OPERATOR":
                authorities.add(new SimpleGrantedAuthority("PERM_DRONE_CONTROL"));
                authorities.add(new SimpleGrantedAuthority("PERM_EMERGENCY_MANAGE"));
                authorities.add(new SimpleGrantedAuthority("PERM_DASHBOARD_ACCESS"));
                // Fall through para incluir permissões de USER
            case "USER":
                authorities.add(new SimpleGrantedAuthority("PERM_PROFILE_VIEW"));
                authorities.add(new SimpleGrantedAuthority("PERM_EMERGENCY_REPORT"));
                break;
        }

        return authorities;
    }


}

package br.com.fiap.gs.service;

import br.com.fiap.gs.model.ConfigAlerta;

import java.util.List;

public interface ConfigAlertaService {
    List<ConfigAlerta> listarTodos();
    ConfigAlerta buscarPorId(Long id);
    ConfigAlerta salvar(ConfigAlerta c);
    ConfigAlerta atualizar(Long id, ConfigAlerta c);
    void deletar(Long id);
}

package br.com.fiap.gs.repository;

import br.com.fiap.gs.model.Sinalizacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SinalizacaoRepository extends JpaRepository<Sinalizacao, Long> {
}

package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record ConfigAlertaEvent(
        Tipo tipo,
        Long id,
        String tipoAlerta,
        Double nivelCritico,
        Double nivelAlerta,
        String acaoRecomendada,
        LocalDateTime dataConfiguracao,
        Long idAreaRisco,
        String nomeArea,
        Long idUsuario,
        String nomeUsuario
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}


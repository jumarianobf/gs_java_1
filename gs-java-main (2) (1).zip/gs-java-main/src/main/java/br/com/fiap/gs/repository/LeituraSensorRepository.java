package br.com.fiap.gs.repository;

import br.com.fiap.gs.model.LeituraSensor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeituraSensorRepository extends JpaRepository<LeituraSensor, Long> {
}

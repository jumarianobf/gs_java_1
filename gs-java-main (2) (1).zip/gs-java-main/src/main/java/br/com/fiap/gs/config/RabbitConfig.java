package br.com.fiap.gs.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

    public static final String EXCHANGE_USUARIOS   = "exchange.usuarios";
    public static final String ROUTING_KEY_USUARIO = "usuario.key";
    public static final String QUEUE_USUARIO       = "fila.usuario";

    // ——— Drones —————————————————————————————————————
    public static final String EXCHANGE_DRONES   = "exchange.drones";
    public static final String ROUTING_KEY_DRONE = "drone.key";
    public static final String QUEUE_DRONE       = "fila.drone";

    @Bean
    public DirectExchange exchangeDrones() {
        return ExchangeBuilder.directExchange(EXCHANGE_DRONES).durable(true).build();
    }

    @Bean
    public Queue filaDrone() {
        return QueueBuilder.durable(QUEUE_DRONE).build();
    }

    @Bean
    public Binding bindingDrone(Queue filaDrone, DirectExchange exchangeDrones) {
        return BindingBuilder.bind(filaDrone)
                .to(exchangeDrones)
                .with(ROUTING_KEY_DRONE);
    }


    // Conversor JSON para objetos Java
    @Bean
    public Jackson2JsonMessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    // Template do Rabbit com conversão JSON
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory,
                                         Jackson2JsonMessageConverter converter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(converter);
        return template;
    }

    // Exchange direta para usuários
    @Bean
    public DirectExchange exchangeUsuarios() {
        return ExchangeBuilder.directExchange(EXCHANGE_USUARIOS).durable(true).build();
    }

    // Fila de usuários
    @Bean
    public Queue filaUsuario() {
        return QueueBuilder.durable(QUEUE_USUARIO).build();
    }

    // Binding: exchange → fila
    @Bean
    public Binding bindingUsuario(Queue filaUsuario, DirectExchange exchangeUsuarios) {
        return BindingBuilder.bind(filaUsuario)
                .to(exchangeUsuarios)
                .with(ROUTING_KEY_USUARIO);
    }

    // Listener factory
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory cf,
            Jackson2JsonMessageConverter converter
    ) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(cf);
        factory.setMessageConverter(converter);
        factory.setDefaultRequeueRejected(false);
        return factory;
    }
}

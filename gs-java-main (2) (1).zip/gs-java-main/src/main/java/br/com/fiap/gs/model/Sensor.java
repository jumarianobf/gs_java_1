package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Sensor")
public class Sensor {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_sensor")
    @SequenceGenerator(name = "seq_sensor", sequenceName = "seq_sensor", allocationSize = 1)
    @Column(name = "id_sensor")
    private Long idSensor;

    @Column(name = "tipo_sensor", length = 20)
    private String tipoSensor;

    @Column(name = "descricao")
    private String descricao;

    @Column(name = "unidade_medida", length = 10, nullable = false)
    private String unidadeMedida;

    @Column(name = "status", length = 20)
    private String status;

    @Column(name = "intervalo_leitura")
    private Integer intervaloLeitura;

    @Column(name = "data_instalacao")
    private LocalDateTime dataInstalacao;

    @ManyToOne
    @JoinColumn(name = "id_area")
    private AreaRisco area;
}


package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.ConfigAlertaEvent;
import br.com.fiap.gs.model.ConfigAlerta;
import br.com.fiap.gs.repository.ConfigAlertaRepository;
import br.com.fiap.gs.service.ConfigAlertaService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConfigAlertaImpl implements ConfigAlertaService {

    private final ConfigAlertaRepository repository;
    private final RabbitTemplate rabbitTemplate;

    public ConfigAlertaImpl(ConfigAlertaRepository repository, RabbitTemplate rabbitTemplate) {
        this.repository = repository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(ConfigAlertaEvent.Tipo tipo, ConfigAlerta c) {
        ConfigAlertaEvent evt = new ConfigAlertaEvent(
                tipo,
                c.getIdConfig(),
                c.getTipoAlerta(),
                c.getNivelCritico(),
                c.getNivelAlerta(),
                c.getAcaoRecomendada(),
                c.getDataConfiguracao(),
                c.getArea() != null ? c.getArea().getIdArea() : null,
                c.getArea() != null ? c.getArea().getNomeArea() : null,
                c.getUsuario() != null ? c.getUsuario().getIdUsuario() : null,
                c.getUsuario() != null ? c.getUsuario().getNome() : null
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public ConfigAlerta salvar(ConfigAlerta c) {
        ConfigAlerta salvo = repository.save(c);
        publishEvent(ConfigAlertaEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public ConfigAlerta atualizar(Long id, ConfigAlerta c) {
        ConfigAlerta existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Configuração não encontrada"));
        existente.setTipoAlerta(c.getTipoAlerta());
        existente.setNivelCritico(c.getNivelCritico());
        existente.setNivelAlerta(c.getNivelAlerta());
        existente.setAcaoRecomendada(c.getAcaoRecomendada());
        existente.setDataConfiguracao(c.getDataConfiguracao());
        existente.setArea(c.getArea());
        existente.setUsuario(c.getUsuario());
        ConfigAlerta atualizado = repository.save(existente);
        publishEvent(ConfigAlertaEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        ConfigAlerta existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Configuração não encontrada"));
        repository.deleteById(id);
        publishEvent(ConfigAlertaEvent.Tipo.DELETADO, existente);
    }

    @Override
    public List<ConfigAlerta> listarTodos() {
        return repository.findAll();
    }

    @Override
    public ConfigAlerta buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Configuração não encontrada"));
    }
}

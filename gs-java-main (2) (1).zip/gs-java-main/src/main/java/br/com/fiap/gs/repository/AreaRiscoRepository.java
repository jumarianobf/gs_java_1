package br.com.fiap.gs.repository;

import br.com.fiap.gs.model.AreaRisco;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AreaRiscoRepository extends JpaRepository<AreaRisco, Long> {
    @Query("SELECT COUNT(a) FROM AreaRisco a WHERE a.status = :status")
    long countByStatus(@Param("status") String status);

    @Query("SELECT a FROM AreaRisco a ORDER BY a.dataCadastro DESC")
    List<AreaRisco> findTop5ByOrderByDataCadastroDesc();

    @Query(value = "SELECT * FROM area_risco ORDER BY data_cadastro DESC LIMIT :limite", nativeQuery = true)
    List<AreaRisco> findUltimas(int limite);
}

package br.com.fiap.gs.messaging;

public record AlertaEvent(
        Tipo tipo,
        Long id,
        String tipoAlerta,
        String status,
        String gravidade,
        String descricao,
        Long idArea,
        Long idDrone,
        Long idUsuario
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}
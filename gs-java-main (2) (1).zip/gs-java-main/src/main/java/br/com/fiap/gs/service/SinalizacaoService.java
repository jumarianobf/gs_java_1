package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Sinalizacao;

import java.util.List;

public interface SinalizacaoService {
    List<Sinalizacao> listarTodos();
    Sinalizacao buscarPorId(Long id);
    Sinalizacao salvar(Sinalizacao s);
    Sinalizacao atualizar(Long id, Sinalizacao s);
    void deletar(Long id);
}

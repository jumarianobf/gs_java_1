package br.com.fiap.gs.service;

import br.com.fiap.gs.model.LogDrone;

import java.util.List;

public interface LogDroneService {
    List<LogDrone> listarTodos();
    LogDrone buscarPorId(Long id);
    LogDrone salvar(LogDrone l);
    LogDrone atualizar(Long id, LogDrone l);
    void deletar(Long id);
}

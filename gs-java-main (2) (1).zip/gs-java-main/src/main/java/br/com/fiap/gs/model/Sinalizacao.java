package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Sinalizacao")
public class Sinalizacao {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_sinalizacao")
    @SequenceGenerator(name = "seq_sinalizacao", sequenceName = "seq_sinalizacao", allocationSize = 1)
    @Column(name = "id_sinalizacao")
    private Long idSinalizacao;

    @Column(name = "tipo_sinalizacao")
    private String tipoSinalizacao;

    @Column(name = "descricao")
    private String descricao;

    @Column(name = "status", length = 10)
    private String status;

    @Column(name = "data_instalacao")
    private LocalDateTime dataInstalacao;

    @ManyToOne
    @JoinColumn(name = "id_area")
    private AreaRisco area;
}
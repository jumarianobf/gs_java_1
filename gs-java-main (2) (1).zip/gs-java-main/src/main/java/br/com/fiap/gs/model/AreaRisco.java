package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "AreaRisco")
public class AreaRisco {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_area_risco")
    @SequenceGenerator(name = "seq_area_risco", sequenceName = "seq_area_risco", allocationSize = 1)
    @Column(name = "id_area")
    private Long idArea;

    @Column(name = "nome_area", nullable = false, length = 100)
    private String nomeArea;

    @Column(name = "descricao", length = 255)
    private String descricao;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "status", length = 20)
    private String status;

    @Column(name = "raio_cobertura")
    private Double raioCobertura;

    @Column(name = "data_cadastro")
    @CreationTimestamp
    private LocalDateTime dataCadastro;
}

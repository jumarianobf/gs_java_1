package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Drone")
public class Drone {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_drone")
    @SequenceGenerator(name = "seq_drone", sequenceName = "seq_drone", allocationSize = 1)
    @Column(name = "id_drone")
    private Long idDrone;

    @Column(name = "nome", nullable = false,  length = 50)
    private String nome;

    @Column(name = "modelo", nullable = false,  length = 20)
    private String modelo;

    @Column(name = "status", length = 20)
    private String status;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "bateria")
    private Integer bateria;

    @Column(name = "capacidade_carga")
    private Double capacidadeCarga;

    @Column(name = "data_ultima_manutencao")
    private LocalDateTime dataUltimaManutencao;

    @Column(name = "horario_operacao", length = 20)
    private String horarioOperacao;

    @Column(name = "data_cadastro")
    private LocalDateTime dataCadastro;
}


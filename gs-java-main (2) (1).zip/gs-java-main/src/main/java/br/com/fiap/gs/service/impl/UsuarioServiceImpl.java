package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.UsuarioEvent;
import br.com.fiap.gs.model.Usuario;
import br.com.fiap.gs.repository.UsuarioRepository;
import br.com.fiap.gs.service.UsuarioService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RabbitTemplate rabbitTemplate;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UsuarioServiceImpl(UsuarioRepository usuarioRepository, RabbitTemplate rabbitTemplate, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.rabbitTemplate = rabbitTemplate;
        this.passwordEncoder = passwordEncoder;
    }

    private void publishEvent(UsuarioEvent.Tipo tipo, Usuario u) {
        UsuarioEvent evt = new UsuarioEvent(
                tipo,
                u.getIdUsuario(),
                u.getNome(),
                u.getEmail(),
                u.getSenhaHash(),
                u.getNivelAcesso(),
                u.getStatus(),
                u.getDataCriacao()
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado com ID: " + id));
    }

    @Override
    public Usuario buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado com email: " + email));
    }

    @Override
    public Usuario salvar(Usuario usuario) {
        if (usuarioRepository.existsByEmail(usuario.getEmail())) {
            throw new RuntimeException("Email já cadastrado no sistema.");
        }

        if (usuario.getSenhaHash() != null && !usuario.getSenhaHash().startsWith("$2a$")) {
            usuario.setSenhaHash(passwordEncoder.encode(usuario.getSenhaHash()));
        }


        usuario.setDataCriacao(LocalDateTime.now());
        usuario.setDataAtualizacao(LocalDateTime.now());

        Usuario salvo = usuarioRepository.save(usuario);
        publishEvent(UsuarioEvent.Tipo.CRIADO, salvo); // 🔁 PRODUÇÃO DE EVENTO
        return salvo;
    }


    public Usuario atualizar(Long id, Usuario usuarioAtualizado) {
        Usuario usuarioExistente = buscarPorId(id);

        // Verificar se email já existe (exceto para o próprio usuário)
        if (!usuarioExistente.getEmail().equals(usuarioAtualizado.getEmail()) &&
                usuarioRepository.existsByEmail(usuarioAtualizado.getEmail())) {
            throw new RuntimeException("Email já cadastrado no sistema.");
        }

        // Atualizar campos
        usuarioExistente.setNome(usuarioAtualizado.getNome());
        usuarioExistente.setEmail(usuarioAtualizado.getEmail());
        usuarioExistente.setNivelAcesso(usuarioAtualizado.getNivelAcesso());
        usuarioExistente.setStatus(usuarioAtualizado.getStatus());
        usuarioExistente.setDataAtualizacao(LocalDateTime.now());

        // Só atualizar senha se foi fornecida uma nova
        if (usuarioAtualizado.getSenhaHash() != null && !usuarioAtualizado.getSenhaHash().isEmpty()) {
            usuarioExistente.setSenhaHash(passwordEncoder.encode(usuarioAtualizado.getSenhaHash()));
        }

        return usuarioRepository.save(usuarioExistente);
    }

    public void deletar(Long id) {
        Usuario usuario = buscarPorId(id);
        usuarioRepository.delete(usuario);
    }

    public List<Usuario> buscarPorStatus(String status) {
        return usuarioRepository.findByStatus(status);
    }

    public List<Usuario> buscarPorNivelAcesso(String nivelAcesso) {
        return usuarioRepository.findByNivelAcesso(nivelAcesso);
    }

    public Long contarUsuariosAtivos() {
        return usuarioRepository.countActiveUsers();
    }

    public Long contarPorNivel(String nivel) {
        return usuarioRepository.countByNivelAcesso(nivel);
    }
}

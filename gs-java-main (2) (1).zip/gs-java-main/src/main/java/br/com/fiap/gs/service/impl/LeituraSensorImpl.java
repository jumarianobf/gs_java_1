package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.*;
import br.com.fiap.gs.model.*;
import br.com.fiap.gs.repository.*;
import br.com.fiap.gs.service.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeituraSensorImpl implements LeituraSensorService {

    private final LeituraSensorRepository leituraSensorRepository;
    private final RabbitTemplate rabbitTemplate;

    public LeituraSensorImpl(LeituraSensorRepository leituraSensorRepository, RabbitTemplate rabbitTemplate) {
        this.leituraSensorRepository = leituraSensorRepository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(LeituraSensorEvent.Tipo tipo, LeituraSensor l) {
        LeituraSensorEvent evt = new LeituraSensorEvent(
                tipo,
                l.getIdLeitura(),
                l.getDataHora(),
                l.getValorLeitura(),
                l.getUnidadeMedida(),
                l.getStatus(),
                l.getSensor() != null ? l.getSensor().getIdSensor() : null
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<LeituraSensor> listarTodos() {
        return leituraSensorRepository.findAll();
    }

    @Override
    public LeituraSensor buscarPorId(Long id) {
        return leituraSensorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leitura do sensor não encontrada"));
    }

    @Override
    public LeituraSensor salvar(LeituraSensor l) {
        LeituraSensor salvo = leituraSensorRepository.save(l);
        publishEvent(LeituraSensorEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public LeituraSensor atualizar(Long id, LeituraSensor l) {
        LeituraSensor existente = buscarPorId(id);
        existente.setDataHora(l.getDataHora());
        existente.setValorLeitura(l.getValorLeitura());
        existente.setUnidadeMedida(l.getUnidadeMedida());
        existente.setStatus(l.getStatus());
        existente.setSensor(l.getSensor());
        LeituraSensor atualizado = leituraSensorRepository.save(existente);
        publishEvent(LeituraSensorEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        LeituraSensor existente = buscarPorId(id);
        leituraSensorRepository.deleteById(id);
        publishEvent(LeituraSensorEvent.Tipo.DELETADO, existente);
    }
}


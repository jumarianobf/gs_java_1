package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Sensor;

import java.util.List;

public interface SensorService {
    List<Sensor> listarTodos();
    Sensor buscarPorId(Long id);
    Sensor salvar(Sensor s);
    Sensor atualizar(Long id, Sensor s);
    void deletar(Long id);
}


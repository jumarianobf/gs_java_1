package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.ConfigAlerta;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.ConfigAlertaService;
import br.com.fiap.gs.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/config-alerta")
public class ConfigAlertaController {

    @Autowired
    private ConfigAlertaService configAlertaService;

    @Autowired
    private AreaRiscoService areaRiscoService;

    @Autowired
    private UsuarioService usuarioService;

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listar(Model model) {
        List<ConfigAlerta> lista = configAlertaService.listarTodos();
        model.addAttribute("configs", lista);
        return "config-alerta/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("configAlerta", new ConfigAlerta());
        carregarRelacionamentos(model);
        return "config-alerta/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("configAlerta") ConfigAlerta configAlerta,
                         BindingResult result,
                         RedirectAttributes redirectAttributes,
                         Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            carregarRelacionamentos(model);
            return "config-alerta/form";
        }

        try {
            configAlertaService.salvar(configAlerta);
            redirectAttributes.addFlashAttribute("sucesso", "Configuração salva com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "config-alerta/form";
        }

        return "redirect:/config-alerta";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        try {
            ConfigAlerta config = configAlertaService.buscarPorId(id);
            model.addAttribute("configAlerta", config);
            carregarRelacionamentos(model);
            return "config-alerta/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/config-alerta";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizar(@PathVariable Long id,
                            @Valid @ModelAttribute("configAlerta") ConfigAlerta configAlerta,
                            BindingResult result,
                            RedirectAttributes redirectAttributes,
                            Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            carregarRelacionamentos(model);
            return "config-alerta/form";
        }

        try {
            configAlertaService.atualizar(id, configAlerta);
            redirectAttributes.addFlashAttribute("sucesso", "Configuração atualizada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "config-alerta/form";
        }

        return "redirect:/config-alerta";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletar(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            configAlertaService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Configuração removida com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/config-alerta";
    }

    private void carregarRelacionamentos(Model model) {
        model.addAttribute("areas", areaRiscoService.listarTodos());
        model.addAttribute("usuarios", usuarioService.listarTodos());
    }
}

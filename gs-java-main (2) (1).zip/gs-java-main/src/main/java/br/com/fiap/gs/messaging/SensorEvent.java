package br.com.fiap.gs.messaging;

public record SensorEvent(
        Tipo tipo,
        Long id,
        String tipoSensor,
        String descricao,
        String unidadeMedida,
        String status,
        Integer intervaloLeitura,
        Long idAreaRisco,
        String nomeArea
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}
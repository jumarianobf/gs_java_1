package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Drone;
import br.com.fiap.gs.service.DroneService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/drone")
public class DroneController {

    @Autowired
    private DroneService droneService;

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listarDrones(Model model) {
        List<Drone> drones = droneService.listarTodos();
        model.addAttribute("drones", drones);
        return "drone/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novoDrone(Model model) {
        model.addAttribute("drone", new Drone());
        return "drone/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvarDrone(@Valid @ModelAttribute("drone") Drone drone,
                              BindingResult result,
                              RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "drone/form";
        }

        try {
            droneService.salvar(drone);
            redirectAttributes.addFlashAttribute("sucesso", "Drone salvo com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
            return "drone/form";
        }

        return "redirect:/drone";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editarDrone(@PathVariable Long id, Model model) {
        try {
            Drone drone = droneService.buscarPorId(id);
            model.addAttribute("drone", drone);
            return "drone/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/drone";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizarDrone(@PathVariable Long id,
                                 @Valid @ModelAttribute("drone") Drone drone,
                                 BindingResult result,
                                 RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "drone/form";
        }

        try {
            droneService.atualizar(id, drone);
            redirectAttributes.addFlashAttribute("sucesso", "Drone atualizado com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
            return "drone/form";
        }

        return "redirect:/drone";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletarDrone(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            droneService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Drone removido com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/drone";
    }
}

package br.com.fiap.gs.service;

import br.com.fiap.gs.model.LeituraSensor;

import java.util.List;

public interface LeituraSensorService {
    List<LeituraSensor> listarTodos();
    LeituraSensor buscarPorId(Long id);
    LeituraSensor salvar(LeituraSensor l);
    LeituraSensor atualizar(Long id, LeituraSensor l);
    void deletar(Long id);
}

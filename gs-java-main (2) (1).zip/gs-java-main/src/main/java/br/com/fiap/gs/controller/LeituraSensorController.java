package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.LeituraSensor;
import br.com.fiap.gs.service.LeituraSensorService;
import br.com.fiap.gs.service.SensorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/leitura-sensor")
public class LeituraSensorController {

    private final LeituraSensorService leituraSensorService;
    private final SensorService sensorService;

    @Autowired
    public LeituraSensorController(LeituraSensorService leituraSensorService, SensorService sensorService) {
        this.leituraSensorService = leituraSensorService;
        this.sensorService = sensorService;
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listarLeituras(Model model) {
        List<LeituraSensor> leituras = leituraSensorService.listarTodos();
        model.addAttribute("leituras", leituras);
        return "leiturasensor/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novaLeitura(Model model) {
        model.addAttribute("leituraSensor", new LeituraSensor());
        model.addAttribute("sensores", sensorService.listarTodos());
        return "leiturasensor/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvarLeitura(@Valid @ModelAttribute("leituraSensor") LeituraSensor leituraSensor,
                                BindingResult result,
                                RedirectAttributes redirectAttributes,
                                Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            model.addAttribute("sensores", sensorService.listarTodos());
            return "leiturasensor/form";
        }

        try {
            leituraSensorService.salvar(leituraSensor);
            redirectAttributes.addFlashAttribute("sucesso", "Leitura salva com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("sensores", sensorService.listarTodos());
            return "leiturasensor/form";
        }

        return "redirect:/leitura-sensor";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editarLeitura(@PathVariable Long id, Model model) {
        try {
            LeituraSensor leitura = leituraSensorService.buscarPorId(id);
            model.addAttribute("leituraSensor", leitura);
            model.addAttribute("sensores", sensorService.listarTodos());
            return "leiturasensor/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/leitura-sensor";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizarLeitura(@PathVariable Long id,
                                   @Valid @ModelAttribute("leituraSensor") LeituraSensor leituraSensor,
                                   BindingResult result,
                                   RedirectAttributes redirectAttributes,
                                   Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            model.addAttribute("sensores", sensorService.listarTodos());
            return "leiturasensor/form";
        }

        try {
            leituraSensorService.atualizar(id, leituraSensor);
            redirectAttributes.addFlashAttribute("sucesso", "Leitura atualizada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("sensores", sensorService.listarTodos());
            return "leiturasensor/form";
        }

        return "redirect:/leitura-sensor";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletarLeitura(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            leituraSensorService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Leitura removida com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/leitura-sensor";
    }
}

package br.com.fiap.gs.service;

import br.com.fiap.gs.model.Drone;

import java.util.List;

public interface DroneService {
    List<Drone> listarTodos();
    Drone buscarPorId(Long id);
    Drone salvar(Drone d);
    Drone atualizar(Long id, Drone d);
    void deletar(Long id);
    long contarAtivos();

}

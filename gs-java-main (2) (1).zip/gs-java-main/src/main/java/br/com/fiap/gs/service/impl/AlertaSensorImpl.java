package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.AlertaSensorEvent;
import br.com.fiap.gs.model.AlertaSensor;
import br.com.fiap.gs.repository.AlertaSensorRepository;
import br.com.fiap.gs.service.AlertaSensorService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlertaSensorImpl implements AlertaSensorService {

    private final AlertaSensorRepository repository;
    private final RabbitTemplate rabbitTemplate;

    public AlertaSensorImpl(AlertaSensorRepository repository, RabbitTemplate rabbitTemplate) {
        this.repository = repository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(AlertaSensorEvent.Tipo tipo, AlertaSensor a) {
        AlertaSensorEvent evt = new AlertaSensorEvent(
                tipo,
                a.getIdAlertaSensor(),
                a.getValorDisparo(),
                a.getAlerta().getIdAlerta(),
                a.getSensor().getTipoSensor()
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<AlertaSensor> listarTodos() {
        return repository.findAll();
    }

    @Override
    public AlertaSensor buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("AlertaSensor não encontrado"));
    }

    @Override
    public AlertaSensor salvar(AlertaSensor a) {
        AlertaSensor salvo = repository.save(a);
        publishEvent(AlertaSensorEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public AlertaSensor atualizar(Long id, AlertaSensor a) {
        AlertaSensor existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("AlertaSensor não encontrado"));
        existente.setValorDisparo(a.getValorDisparo());
        existente.setAlerta(a.getAlerta());
        existente.setSensor(a.getSensor());
        AlertaSensor atualizado = repository.save(existente);
        publishEvent(AlertaSensorEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        AlertaSensor existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("AlertaSensor não encontrado"));
        repository.deleteById(id);
        publishEvent(AlertaSensorEvent.Tipo.DELETADO, existente);
    }
}
package br.com.fiap.gs.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "ConfigAlerta")
public class ConfigAlerta {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_config_alerta")
    @SequenceGenerator(name = "seq_config_alerta", sequenceName = "seq_config_alerta", allocationSize = 1)
    @Column(name = "id_config")
    private Long idConfig;

    @Column(name = "tipo_alerta", length = 20)
    private String tipoAlerta;

    @Column(name = "nivel_critico", nullable = false)
    private Double nivelCritico;

    @Column(name = "nivel_alerta", nullable = false)
    private Double nivelAlerta;

    @Lob
    @Column(name = "acao_recomendada", nullable = false)
    private String acaoRecomendada;

    @Column(name = "data_configuracao")
    private LocalDateTime dataConfiguracao;

    @ManyToOne
    @JoinColumn(name = "id_area")
    private AreaRisco area;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;
}

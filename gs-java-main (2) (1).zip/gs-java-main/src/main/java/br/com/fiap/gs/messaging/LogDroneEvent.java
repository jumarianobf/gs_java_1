package br.com.fiap.gs.messaging;

import java.time.LocalDateTime;

public record LogDroneEvent(
        Tipo tipo,
        Long id,
        LocalDateTime dataHora,
        String acaoRealizada,
        String descricao,
        Double latitude,
        Double longitude,
        String status,
        Long idDrone,
        Long idUsuario
) {
    public enum Tipo {
        CRIADO,
        ATUALIZADO,
        DELETADO
    }
}
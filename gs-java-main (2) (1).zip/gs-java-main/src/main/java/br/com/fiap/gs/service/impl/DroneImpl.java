package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.*;
import br.com.fiap.gs.model.*;
import br.com.fiap.gs.repository.*;
import br.com.fiap.gs.service.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DroneImpl implements DroneService {

    private final DroneRepository repository;
    private final RabbitTemplate rabbitTemplate;

    public DroneImpl(DroneRepository repository, RabbitTemplate rabbitTemplate) {
        this.repository = repository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(DroneEvent.Tipo tipo, Drone d) {
        DroneEvent evt = new DroneEvent(
                tipo,
                d.getIdDrone(),
                d.getNome(),
                d.getModelo(),
                d.getStatus(),
                d.getLatitude(),
                d.getLongitude(),
                d.getBateria(),
                d.getCapacidadeCarga(),
                d.getDataUltimaManutencao(),
                d.getHorarioOperacao(),
                d.getDataCadastro()
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_DRONES, RabbitConfig.ROUTING_KEY_DRONE, evt);
    }

    @Override
    public List<Drone> listarTodos() {
        return repository.findAll();
    }

    @Override
    public Drone buscarPorId(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Drone não encontrado"));
    }

    @Override
    public Drone salvar(Drone d) {
        Drone salvo = repository.save(d);
        publishEvent(DroneEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public Drone atualizar(Long id, Drone d) {
        Drone existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Drone não encontrado"));
        existente.setNome(d.getNome());
        existente.setModelo(d.getModelo());
        existente.setStatus(d.getStatus());
        existente.setLatitude(d.getLatitude());
        existente.setLongitude(d.getLongitude());
        existente.setBateria(d.getBateria());
        existente.setCapacidadeCarga(d.getCapacidadeCarga());
        existente.setDataUltimaManutencao(d.getDataUltimaManutencao());
        existente.setHorarioOperacao(d.getHorarioOperacao());
        existente.setDataCadastro(d.getDataCadastro());
        Drone atualizado = repository.save(existente);
        publishEvent(DroneEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        Drone existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Drone não encontrado"));
        repository.deleteById(id);
        publishEvent(DroneEvent.Tipo.DELETADO, existente);
    }

    @Override
    public long contarAtivos() {
        return repository.countAtivos();
    }

}

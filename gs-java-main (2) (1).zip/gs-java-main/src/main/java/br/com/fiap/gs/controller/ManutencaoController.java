package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Manutencao;
import br.com.fiap.gs.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/manutencoes")
public class ManutencaoController {

    private final ManutencaoService manutencaoService;
    private final DroneService droneService;
    private final SensorService sensorService;
    private final SinalizacaoService sinalizacaoService;
    private final UsuarioService usuarioService;

    @Autowired
    public ManutencaoController(
            ManutencaoService manutencaoService,
            DroneService droneService,
            SensorService sensorService,
            SinalizacaoService sinalizacaoService,
            UsuarioService usuarioService
    ) {
        this.manutencaoService = manutencaoService;
        this.droneService = droneService;
        this.sensorService = sensorService;
        this.sinalizacaoService = sinalizacaoService;
        this.usuarioService = usuarioService;
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listarManutencoes(Model model) {
        List<Manutencao> manutencoes = manutencaoService.listarTodos();
        model.addAttribute("manutencoes", manutencoes);
        return "manutencao/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novaManutencao(Model model) {
        model.addAttribute("manutencao", new Manutencao());
        carregarRelacionamentos(model);
        return "manutencao/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvarManutencao(
            @Valid @ModelAttribute("manutencao") Manutencao manutencao,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            carregarRelacionamentos(model);
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "manutencao/form";
        }

        try {
            manutencaoService.salvar(manutencao);
            redirectAttributes.addFlashAttribute("sucesso", "Manutenção cadastrada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "manutencao/form";
        }

        return "redirect:/manutencoes";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editarManutencao(@PathVariable Long id, Model model) {
        try {
            Manutencao manutencao = manutencaoService.buscarPorId(id);
            model.addAttribute("manutencao", manutencao);
            carregarRelacionamentos(model);
            return "manutencao/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/manutencoes";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizarManutencao(
            @PathVariable Long id,
            @Valid @ModelAttribute("manutencao") Manutencao manutencao,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            carregarRelacionamentos(model);
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "manutencao/form";
        }

        try {
            manutencaoService.atualizar(id, manutencao);
            redirectAttributes.addFlashAttribute("sucesso", "Manutenção atualizada com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "manutencao/form";
        }

        return "redirect:/manutencoes";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletarManutencao(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            manutencaoService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Manutenção removida com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/manutencoes";
    }

    private void carregarRelacionamentos(Model model) {
        model.addAttribute("drones", droneService.listarTodos());
        model.addAttribute("sensores", sensorService.listarTodos());
        model.addAttribute("sinalizacoes", sinalizacaoService.listarTodos());
        model.addAttribute("usuarios", usuarioService.listarTodos());
    }
}

package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.Sensor;
import br.com.fiap.gs.service.AreaRiscoService;
import br.com.fiap.gs.service.SensorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/sensores")
public class SensorController {

    private final SensorService sensorService;
    private final AreaRiscoService areaRiscoService;

    @Autowired
    public SensorController(SensorService sensorService, AreaRiscoService areaRiscoService) {
        this.sensorService = sensorService;
        this.areaRiscoService = areaRiscoService;
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listarSensores(Model model) {
        List<Sensor> sensores = sensorService.listarTodos();
        model.addAttribute("sensores", sensores);
        return "sensor/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novoSensor(Model model) {
        model.addAttribute("sensor", new Sensor());
        model.addAttribute("areas", areaRiscoService.listarTodos());
        return "sensor/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvarSensor(
            @Valid @ModelAttribute("sensor") Sensor sensor,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            model.addAttribute("areas", areaRiscoService.listarTodos());
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "sensor/form";
        }

        try {
            sensorService.salvar(sensor);
            redirectAttributes.addFlashAttribute("sucesso", "Sensor cadastrado com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "sensor/form";
        }

        return "redirect:/sensores";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editarSensor(@PathVariable Long id, Model model) {
        try {
            Sensor sensor = sensorService.buscarPorId(id);
            model.addAttribute("sensor", sensor);
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "sensor/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/sensores";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizarSensor(
            @PathVariable Long id,
            @Valid @ModelAttribute("sensor") Sensor sensor,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            model.addAttribute("areas", areaRiscoService.listarTodos());
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "sensor/form";
        }

        try {
            sensorService.atualizar(id, sensor);
            redirectAttributes.addFlashAttribute("sucesso", "Sensor atualizado com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("areas", areaRiscoService.listarTodos());
            return "sensor/form";
        }

        return "redirect:/sensores";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletarSensor(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            sensorService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Sensor removido com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/sensores";
    }
}

package br.com.fiap.gs.service;

import br.com.fiap.gs.model.AreaRisco;

import java.util.List;

public interface AreaRiscoService {
    List<AreaRisco> listarTodos();
    AreaRisco buscarPorId(Long id);
    AreaRisco salvar(AreaRisco a);
    AreaRisco atualizar(Long id, AreaRisco a);
    void deletar(Long id);
    long contarPorStatus(String status);
    List<AreaRisco> ultimas(int limite);
}

package br.com.fiap.gs.controller;

import br.com.fiap.gs.model.LogDrone;
import br.com.fiap.gs.service.DroneService;
import br.com.fiap.gs.service.LogDroneService;
import br.com.fiap.gs.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/log-drone")
public class LogDroneController {

    private final LogDroneService logDroneService;
    private final DroneService droneService;
    private final UsuarioService usuarioService;

    @Autowired
    public LogDroneController(
            LogDroneService logDroneService,
            DroneService droneService,
            UsuarioService usuarioService
    ) {
        this.logDroneService = logDroneService;
        this.droneService = droneService;
        this.usuarioService = usuarioService;
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping
    public String listarLogs(Model model) {
        List<LogDrone> logs = logDroneService.listarTodos();
        model.addAttribute("logs", logs);
        return "logdrone/lista";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/novo")
    public String novoLog(Model model) {
        model.addAttribute("logDrone", new LogDrone());
        carregarRelacionamentos(model);
        return "logdrone/form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/salvar")
    public String salvarLog(
            @Valid @ModelAttribute("logDrone") LogDrone logDrone,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            carregarRelacionamentos(model);
            return "logdrone/form";
        }

        try {
            logDroneService.salvar(logDrone);
            redirectAttributes.addFlashAttribute("sucesso", "Log salvo com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "logdrone/form";
        }

        return "redirect:/log-drone";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/editar/{id}")
    public String editarLog(@PathVariable Long id, Model model) {
        try {
            LogDrone log = logDroneService.buscarPorId(id);
            model.addAttribute("logDrone", log);
            carregarRelacionamentos(model);
            return "logdrone/form";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "redirect:/log-drone";
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/atualizar/{id}")
    public String atualizarLog(
            @PathVariable Long id,
            @Valid @ModelAttribute("logDrone") LogDrone logDrone,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Preencha todos os campos obrigatórios.");
            carregarRelacionamentos(model);
            return "logdrone/form";
        }

        try {
            logDroneService.atualizar(id, logDrone);
            redirectAttributes.addFlashAttribute("sucesso", "Log atualizado com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            carregarRelacionamentos(model);
            return "logdrone/form";
        }

        return "redirect:/log-drone";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/deletar/{id}")
    public String deletarLog(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            logDroneService.deletar(id);
            redirectAttributes.addFlashAttribute("sucesso", "Log removido com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/log-drone";
    }

    private void carregarRelacionamentos(Model model) {
        model.addAttribute("drones", droneService.listarTodos());
        model.addAttribute("usuarios", usuarioService.listarTodos());
    }
}

package br.com.fiap.gs.service.impl;

import br.com.fiap.gs.config.RabbitConfig;
import br.com.fiap.gs.messaging.SensorEvent;
import br.com.fiap.gs.model.Sensor;
import br.com.fiap.gs.repository.SensorRepository;
import br.com.fiap.gs.service.SensorService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SensorImpl implements SensorService {

    private final SensorRepository sensorRepository;
    private final RabbitTemplate rabbitTemplate;

    public SensorImpl(SensorRepository sensorRepository, RabbitTemplate rabbitTemplate) {
        this.sensorRepository = sensorRepository;
        this.rabbitTemplate = rabbitTemplate;
    }

    private void publishEvent(SensorEvent.Tipo tipo, Sensor s) {
        SensorEvent evt = new SensorEvent(
                tipo,
                s.getIdSensor(),
                s.getTipoSensor(),
                s.getDescricao(),
                s.getUnidadeMedida(),
                s.getStatus(),
                s.getIntervaloLeitura(),
                s.getArea() != null ? s.getArea().getIdArea() : null,
                s.getArea() != null ? s.getArea().getNomeArea() : null
        );
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_USUARIOS, RabbitConfig.ROUTING_KEY_USUARIO, evt);
    }

    @Override
    public List<Sensor> listarTodos() {
        return sensorRepository.findAll();
    }

    @Override
    public Sensor buscarPorId(Long id) {
        return sensorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sensor não encontrado"));
    }

    @Override
    public Sensor salvar(Sensor s) {
        Sensor salvo = sensorRepository.save(s);
        publishEvent(SensorEvent.Tipo.CRIADO, salvo);
        return salvo;
    }

    @Override
    public Sensor atualizar(Long id, Sensor s) {
        Sensor existente = buscarPorId(id);
        existente.setTipoSensor(s.getTipoSensor());
        existente.setDescricao(s.getDescricao());
        existente.setUnidadeMedida(s.getUnidadeMedida());
        existente.setStatus(s.getStatus());
        existente.setIntervaloLeitura(s.getIntervaloLeitura());
        existente.setDataInstalacao(s.getDataInstalacao());
        existente.setArea(s.getArea());
        Sensor atualizado = sensorRepository.save(existente);
        publishEvent(SensorEvent.Tipo.ATUALIZADO, atualizado);
        return atualizado;
    }

    @Override
    public void deletar(Long id) {
        Sensor existente = buscarPorId(id);
        sensorRepository.deleteById(id);
        publishEvent(SensorEvent.Tipo.DELETADO, existente);
    }
}

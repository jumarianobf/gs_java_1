package br.com.fiap.gs.repository;

import br.com.fiap.gs.model.Sensor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SensorRepository extends JpaRepository<Sensor, Long> {
}
